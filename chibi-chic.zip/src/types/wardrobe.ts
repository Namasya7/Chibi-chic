export type AppSection = 'studio' | 'lookbook' | 'challenge' | 'guide';

export type CategoryId =
  | 'face'
  | 'hair'
  | 'dresses'
  | 'tops'
  | 'bottoms'
  | 'socks'
  | 'shoes'
  | 'headwear'
  | 'accessories'
  | 'companions'
  | 'backdrops';

export type SkinToneId =
  | 'porcelain'
  | 'peach'
  | 'warmIvory'
  | 'honey'
  | 'caramel'
  | 'espresso';

export type EyeStyleId =
  | 'jewelRound'
  | 'starrySparkle'
  | 'winkCharm'
  | 'sleepyDoe'
  | 'catEye'
  | 'heartShine';

export type MouthStyleId =
  | 'tinyDot'
  | 'sweetSmile'
  | 'kitty'
  | 'happyOpen'
  | 'shyPout'
  | 'winkSmile';

export type BlushStyleId =
  | 'softOval'
  | 'peachDust'
  | 'heartCheek'
  | 'freckles'
  | 'none';

export type HairStyleId =
  | 'bobBuns'
  | 'himeLong'
  | 'twinTails'
  | 'fluffyPuff'
  | 'sidePony'
  | 'wolfBob'
  | 'braidCrown'
  | 'curlyWaves';

export type DressId =
  | 'none'
  | 'capeletBow'
  | 'strawberryLolita'
  | 'maidFrill'
  | 'starlightGown'
  | 'academySet'
  | 'cozyPajama';

export type TopId =
  | 'none'
  | 'peterPanBlouse'
  | 'knitCardigan'
  | 'sailorTop'
  | 'offShoulderFrill'
  | 'oversizedHoodie'
  | 'sweetheartTee';

export type BottomId =
  | 'none'
  | 'pleatedSkirt'
  | 'tieredRuffle'
  | 'denimShorts'
  | 'cozyBloomers'
  | 'highTrousers'
  | 'pinaforeSkirt';

export type SockId =
  | 'none'
  | 'ankleFrill'
  | 'kneeRibbon'
  | 'stripedOverKnee'
  | 'laceTights'
  | 'fluffyWarmers';

export type ShoeId =
  | 'none'
  | 'bowMaryJanes'
  | 'platformLoafers'
  | 'ribbonBallet'
  | 'laceBoots'
  | 'bunnySlippers'
  | 'starSneakers';

export type HeadwearId =
  | 'none'
  | 'twinFlowerBows'
  | 'fluffyBeret'
  | 'catEars'
  | 'crownTiara'
  | 'sailorCap'
  | 'bunnyEars'
  | 'pearlHeadband'
  | 'witchHat';

export type EyewearId =
  | 'none'
  | 'roundGlasses'
  | 'heartSunglasses'
  | 'starMonocle';

export type NeckwearId =
  | 'none'
  | 'giantRibbon'
  | 'pearlChoker'
  | 'cozyScarf'
  | 'bellCollar';

export type BackItemId =
  | 'none'
  | 'angelWings'
  | 'batWings'
  | 'fairyWings'
  | 'ribbonCape';

export type CompanionId =
  | 'none'
  | 'creamLamb'
  | 'bobaCup'
  | 'magicWand'
  | 'plushBear'
  | 'ribbonTote'
  | 'starLantern';

export type BackdropId =
  | 'atelierCream'
  | 'sakuraGarden'
  | 'starryNight'
  | 'pastelBoutique'
  | 'cloudMeadow'
  | 'checkeredCafe';

export interface ColorOption {
  id: string;
  label: string;
  base: string;
  shade: string;
  highlight: string;
}

export interface ChibiOutfit {
  skinTone: SkinToneId;
  eyeStyle: EyeStyleId;
  eyeColor: string;
  mouthStyle: MouthStyleId;
  blushStyle: BlushStyleId;
  hairStyle: HairStyleId;
  hairColor: string;
  dress: DressId;
  dressColor: string;
  dressAccent: string;
  top: TopId;
  topColor: string;
  bottom: BottomId;
  bottomColor: string;
  socks: SockId;
  socksColor: string;
  shoes: ShoeId;
  shoesColor: string;
  headwear: HeadwearId;
  headwearColor: string;
  eyewear: EyewearId;
  neckwear: NeckwearId;
  neckwearColor: string;
  backItem: BackItemId;
  backItemColor: string;
  companion: CompanionId;
  backdrop: BackdropId;
}

export interface SavedLook {
  id: string;
  name: string;
  createdAt: string;
  outfit: ChibiOutfit;
  isPreset?: boolean;
}

export interface WardrobeItemMeta<T extends string = string> {
  id: T;
  name: string;
  styleTag: string;
  tags: string[];
}

export interface StyleChallengePrompt {
  id: string;
  title: string;
  brief: string;
  requiredTags: string[];
  recommendedBackdrop: BackdropId;
  minScore: number;
}
