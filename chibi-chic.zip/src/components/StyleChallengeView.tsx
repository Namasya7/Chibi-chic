import React, { useMemo, useState } from 'react';
import { CheckCircle2, RotateCcw } from 'lucide-react';
import {
  BACKDROP_ITEMS,
  BACK_ITEMS,
  BOTTOM_ITEMS,
  COMPANION_ITEMS,
  DRESS_ITEMS,
  EYEWEAR_ITEMS,
  HAIR_STYLES,
  HEADWEAR_ITEMS,
  NECKWEAR_ITEMS,
  SHOE_ITEMS,
  SOCK_ITEMS,
  STYLE_CHALLENGES,
  TOP_ITEMS,
} from '../data/wardrobeCatalog';
import { ChibiOutfit, StyleChallengePrompt } from '../types/wardrobe';
import { ChibiStageSvg } from './ChibiStageSvg';

interface StyleChallengeViewProps {
  outfit: ChibiOutfit;
  completedIds: string[];
  onCompleteChallenge: (challengeId: string) => void;
  onGoToStudio: () => void;
}

interface EvaluationResult {
  score: number;
  passed: boolean;
  notes: string[];
}

function evaluateOutfitForChallenge(
  outfit: ChibiOutfit,
  challenge: StyleChallengePrompt
): EvaluationResult {
  const equippedTags: string[] = [];

  const collect = (list: { id: string; tags: string[] }[], id: string) => {
    const found = list.find((item) => item.id === id);
    if (found) equippedTags.push(...found.tags);
  };

  collect(HAIR_STYLES, outfit.hairStyle);
  if (outfit.dress !== 'none') {
    collect(DRESS_ITEMS, outfit.dress);
  } else {
    collect(TOP_ITEMS, outfit.top);
    collect(BOTTOM_ITEMS, outfit.bottom);
  }
  collect(SOCK_ITEMS, outfit.socks);
  collect(SHOE_ITEMS, outfit.shoes);
  collect(HEADWEAR_ITEMS, outfit.headwear);
  collect(EYEWEAR_ITEMS, outfit.eyewear);
  collect(NECKWEAR_ITEMS, outfit.neckwear);
  collect(BACK_ITEMS, outfit.backItem);
  collect(COMPANION_ITEMS, outfit.companion);
  collect(BACKDROP_ITEMS, outfit.backdrop);

  const notes: string[] = [];
  let score = 30; // base score for dressing up

  const isFullyDressed =
    outfit.dress !== 'none' || (outfit.top !== 'none' && outfit.bottom !== 'none');
  if (isFullyDressed) {
    score += 20;
    notes.push('Complete outfit silhouette (+20 pts)');
  } else {
    notes.push('Missing a full dress or top & bottom combo (0 pts)');
  }

  if (outfit.shoes !== 'none') {
    score += 10;
    notes.push('Footwear styled (+10 pts)');
  }

  let tagMatches = 0;
  for (const tag of equippedTags) {
    if (challenge.requiredTags.includes(tag)) {
      tagMatches += 1;
    }
  }
  const themeBonus = Math.min(30, tagMatches * 8);
  score += themeBonus;
  notes.push(
    tagMatches > 0
      ? `Theme alignment across ${tagMatches} garment & accessory details (+${themeBonus} pts)`
      : 'No direct theme matches yet — try matching garments in the Studio'
  );

  if (outfit.backdrop === challenge.recommendedBackdrop) {
    score += 10;
    notes.push('Matching scene backdrop (+10 pts)');
  }

  const finalScore = Math.min(100, score);
  return {
    score: finalScore,
    passed: finalScore >= challenge.minScore,
    notes,
  };
}

export const StyleChallengeView: React.FC<StyleChallengeViewProps> = ({
  outfit,
  completedIds,
  onCompleteChallenge,
  onGoToStudio,
}) => {
  const [selectedId, setSelectedId] = useState<string>(STYLE_CHALLENGES[0].id);
  const [submittedResult, setSubmittedResult] = useState<EvaluationResult | null>(null);

  const activeChallenge = useMemo(
    () => STYLE_CHALLENGES.find((c) => c.id === selectedId) ?? STYLE_CHALLENGES[0],
    [selectedId]
  );

  const handleSubmit = () => {
    const res = evaluateOutfitForChallenge(outfit, activeChallenge);
    setSubmittedResult(res);
    if (res.passed) {
      onCompleteChallenge(activeChallenge.id);
    }
  };

  return (
    <section className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#EAE2DE]">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#2D2129] text-balance">
            Style Challenges
          </h1>
          <p className="text-sm text-[#6E5C66] mt-1.5 max-w-xl">
            Pick a runway prompt, style your chibi in the wardrobe studio, and submit your look to earn boutique stamps.
          </p>
        </div>
        <div className="text-xs font-medium text-[#6E5C66] tabular-nums">
          Completed {completedIds.length} / {STYLE_CHALLENGES.length} challenges
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Challenge Selector List */}
        <div className="lg:col-span-7 space-y-3">
          {STYLE_CHALLENGES.map((challenge) => {
            const isActive = challenge.id === activeChallenge.id;
            const isCompleted = completedIds.includes(challenge.id);
            return (
              <button
                key={challenge.id}
                type="button"
                onClick={() => {
                  setSelectedId(challenge.id);
                  setSubmittedResult(null);
                }}
                className={`w-full text-left p-5 rounded-2xl border transition-colors ${
                  isActive
                    ? 'bg-white border-[#C84B78] shadow-xs'
                    : 'bg-white border-[#EAE2DE] hover:border-[#D4C5CB]'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <h2 className="text-base font-semibold text-[#2D2129]">{challenge.title}</h2>
                  {isCompleted && (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#2E7D5B]">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Completed</span>
                    </span>
                  )}
                </div>
                <p className="text-sm text-[#6E5C66] mt-1.5">{challenge.brief}</p>
                <div className="flex items-center gap-2 text-xs text-[#8E7B85] mt-3">
                  <span>Keywords: {challenge.requiredTags.join(' · ')}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">Target {challenge.minScore}+ pts</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Live Submission Card */}
        <div className="lg:col-span-5 bg-white border border-[#EAE2DE] rounded-2xl p-5 space-y-4">
          <div className="bg-[#FAF7F4] border border-[#EAE2DE] rounded-xl overflow-hidden flex items-center justify-center p-2">
            <ChibiStageSvg outfit={outfit} className="w-full max-w-[290px] h-auto" />
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleSubmit}
              className="flex-1 px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#C84B78] text-white hover:bg-[#B23D67] transition-colors whitespace-nowrap shrink-0"
            >
              Submit Current Look
            </button>
            <button
              type="button"
              onClick={onGoToStudio}
              className="px-4 py-2.5 text-xs font-semibold rounded-lg border border-[#DCD2CE] text-[#2D2129] hover:bg-[#F7F2EF] transition-colors whitespace-nowrap shrink-0"
            >
              Edit in Studio
            </button>
          </div>

          {submittedResult && (
            <div className="pt-4 border-t border-[#EDE6E2] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-[#2D2129]">
                  {submittedResult.passed ? 'Challenge Cleared' : 'Keep Styling'}
                </span>
                <span className="text-lg font-display font-semibold text-[#C84B78] tabular-nums">
                  {submittedResult.score} / 100
                </span>
              </div>
              <ul className="space-y-1 text-xs text-[#62505A]">
                {submittedResult.notes.map((note, idx) => (
                  <li key={idx}>· {note}</li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => setSubmittedResult(null)}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#7D6A74] hover:text-[#2D2129] pt-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Clear result</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
