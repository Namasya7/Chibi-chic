import React from 'react';
import { Trash2, ArrowUpRight } from 'lucide-react';
import { ChibiOutfit, SavedLook } from '../types/wardrobe';
import { ChibiStageSvg } from './ChibiStageSvg';

interface LookbookViewProps {
  looks: SavedLook[];
  onLoadLook: (outfit: ChibiOutfit, name: string) => void;
  onDeleteLook: (id: string) => void;
  onReturnToStudio: () => void;
}

export const LookbookView: React.FC<LookbookViewProps> = ({
  looks,
  onLoadLook,
  onDeleteLook,
  onReturnToStudio,
}) => {
  return (
    <section className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#EAE2DE]">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#2D2129] text-balance">
            Saved Lookbook
          </h1>
          <p className="text-sm text-[#6E5C66] mt-1.5 max-w-xl">
            Browse curated boutique presets and outfits you have saved from the dress-up studio. Load any look onto your chibi to keep styling.
          </p>
        </div>
        <button
          type="button"
          onClick={onReturnToStudio}
          className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#C84B78] text-white hover:bg-[#B23D67] transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          Back to Studio
        </button>
      </div>

      {looks.length === 0 ? (
        <div className="bg-white border border-[#EAE2DE] rounded-2xl p-12 text-center">
          <p className="text-base font-medium text-[#2D2129]">No saved looks yet</p>
          <p className="text-sm text-[#7B6973] mt-1">
            Save an outfit in the studio to collect your favorite combinations here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {looks.map((look) => (
            <article
              key={look.id}
              className="bg-white border border-[#EAE2DE] rounded-2xl overflow-hidden flex flex-col"
            >
              <div className="bg-[#FAF7F4] border-b border-[#EAE2DE] aspect-[400/460] flex items-center justify-center p-3">
                <ChibiStageSvg outfit={look.outfit} className="w-full h-full max-h-[340px]" />
              </div>

              <div className="p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="text-base font-semibold text-[#2D2129] truncate">
                    {look.name}
                  </h2>
                  <div className="flex items-center gap-1.5 text-xs text-[#87747E] mt-0.5">
                    <span>{look.isPreset ? 'Curated Preset' : 'Saved Outfit'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{look.createdAt}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {!look.isPreset && (
                    <button
                      type="button"
                      onClick={() => onDeleteLook(look.id)}
                      aria-label={`Delete ${look.name}`}
                      className="p-2 rounded-lg border border-[#EAE2DE] text-[#7D6A74] hover:text-[#B9385E] hover:border-[#E2B7C6] transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onLoadLook(look.outfit, look.name)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#2D2129] text-white hover:bg-[#463640] transition-colors whitespace-nowrap shrink-0"
                  >
                    <span>Wear Look</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
};
