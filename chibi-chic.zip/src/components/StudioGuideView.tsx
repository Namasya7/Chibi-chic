import React from 'react';

interface StudioGuideViewProps {
  onReturnToStudio: () => void;
}

export const StudioGuideView: React.FC<StudioGuideViewProps> = ({ onReturnToStudio }) => {
  return (
    <section className="max-w-3xl space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#EAE2DE]">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#2D2129] text-balance">
            Studio Guide
          </h1>
          <p className="text-sm text-[#6E5C66] mt-1.5">
            How to layer outfits, customize colorways, and save snapshots in Chibi Chic.
          </p>
        </div>
        <button
          type="button"
          onClick={onReturnToStudio}
          className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#C84B78] text-white hover:bg-[#B23D67] transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          Back to Studio
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-[#EAE2DE] rounded-2xl p-6 space-y-2">
          <h2 className="text-base font-semibold text-[#2D2129]">01. Dresses vs. Separates</h2>
          <p className="text-sm text-[#62505A] leading-relaxed">
            Choose a one-piece outfit from Dresses, or mix and match blouses, knitwear, skirts, and trousers from Tops and Bottoms. Picking a separate automatically clears an active dress so layers stay tidy.
          </p>
        </div>

        <div className="bg-white border border-[#EAE2DE] rounded-2xl p-6 space-y-2">
          <h2 className="text-base font-semibold text-[#2D2129]">02. Custom Colorways</h2>
          <p className="text-sm text-[#62505A] leading-relaxed">
            Nearly every category includes a palette of curated boutique swatches. Recolor hair, irises, dresses, trim accents, socks, shoes, bows, and wings independently.
          </p>
        </div>

        <div className="bg-white border border-[#EAE2DE] rounded-2xl p-6 space-y-2">
          <h2 className="text-base font-semibold text-[#2D2129]">03. Multi-Slot Accessories</h2>
          <p className="text-sm text-[#62505A] leading-relaxed">
            Layer headwear, glasses, neck ribbons, wings, and handheld or floor companions together—including the signature Cream Lamb plushie, Boba Tea, or Starlight Wand.
          </p>
        </div>

        <div className="bg-white border border-[#EAE2DE] rounded-2xl p-6 space-y-2">
          <h2 className="text-base font-semibold text-[#2D2129]">04. Lookbook & PNG Export</h2>
          <p className="text-sm text-[#62505A] leading-relaxed">
            Save your favorite combinations to your browser Lookbook for quick switching, or click Save PNG in the top bar to download a crisp high-resolution portrait with its backdrop.
          </p>
        </div>
      </div>
    </section>
  );
};
