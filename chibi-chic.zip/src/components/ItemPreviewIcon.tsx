import React from 'react';
import {
  EYE_COLORS,
  GARMENT_COLORS,
  HAIR_COLORS,
  resolveColor,
} from '../data/wardrobeCatalog';
import { ChibiOutfit } from '../types/wardrobe';

interface ItemPreviewIconProps {
  kind:
    | 'eye'
    | 'mouth'
    | 'blush'
    | 'hair'
    | 'dress'
    | 'top'
    | 'bottom'
    | 'sock'
    | 'shoe'
    | 'headwear'
    | 'eyewear'
    | 'neckwear'
    | 'backItem'
    | 'companion'
    | 'backdrop';
  itemId: string;
  outfit: ChibiOutfit;
}

const LINE = '#4B3644';

export const ItemPreviewIcon: React.FC<ItemPreviewIconProps> = ({ kind, itemId, outfit }) => {
  if (itemId === 'none') {
    return (
      <svg viewBox="0 0 64 64" className="w-11 h-11">
        <circle cx="32" cy="32" r="16" fill="none" stroke="#C5B8BF" strokeWidth="2.2" strokeDasharray="4 4" />
        <line x1="22" y1="42" x2="42" y2="22" stroke="#C5B8BF" strokeWidth="2.2" strokeLinecap="round" />
      </svg>
    );
  }

  const hair = resolveColor(HAIR_COLORS, outfit.hairColor);
  const eye = resolveColor(EYE_COLORS, outfit.eyeColor);
  const dressCol = resolveColor(GARMENT_COLORS, outfit.dressColor, 0);
  const topCol = resolveColor(GARMENT_COLORS, outfit.topColor, 0);
  const bottomCol = resolveColor(GARMENT_COLORS, outfit.bottomColor, 1);
  const sockCol = resolveColor(GARMENT_COLORS, outfit.socksColor, 0);
  const shoeCol = resolveColor(GARMENT_COLORS, outfit.shoesColor, 1);
  const headCol = resolveColor(GARMENT_COLORS, outfit.headwearColor, 1);
  const neckCol = resolveColor(GARMENT_COLORS, outfit.neckwearColor, 2);
  const backCol = resolveColor(GARMENT_COLORS, outfit.backItemColor, 0);

  return (
    <svg viewBox="0 0 64 64" className="w-12 h-12" aria-hidden="true">
      {kind === 'eye' && (
        <g stroke={LINE} strokeWidth="2">
          <ellipse cx="32" cy="34" rx="16" ry="15" fill="#FFFFFF" />
          <ellipse cx="32" cy="35" rx="11" ry="11" fill={eye.base} />
          <circle cx="32" cy="35" r="5" fill={eye.shade} stroke="none" />
          <path d="M14 31 Q32 14 50 31" fill="none" stroke="#362430" strokeWidth="4.2" strokeLinecap="round" />
          <circle cx="26" cy="29" r="3.8" fill="#FFFFFF" stroke="none" />
          {itemId === 'winkCharm' && (
            <path d="M16 34 Q32 22 48 34" fill="#FAF8F6" stroke="#362430" strokeWidth="4" strokeLinecap="round" />
          )}
        </g>
      )}

      {kind === 'mouth' && (
        <g>
          <ellipse cx="32" cy="32" rx="22" ry="16" fill="#FFF2ED" stroke="#EAD7D0" strokeWidth="1.5" />
          {itemId === 'tinyDot' && <path d="M28 33 Q32 35 36 33" fill="none" stroke={LINE} strokeWidth="2.5" strokeLinecap="round" />}
          {itemId === 'sweetSmile' && <path d="M24 30 Q32 39 40 30" fill="none" stroke={LINE} strokeWidth="2.5" strokeLinecap="round" />}
          {itemId === 'kitty' && <path d="M22 31 Q27 37 32 31 Q37 37 42 31" fill="none" stroke={LINE} strokeWidth="2.5" strokeLinecap="round" />}
          {itemId === 'happyOpen' && <path d="M23 29 Q32 43 41 29 Z" fill="#E87A92" stroke={LINE} strokeWidth="2" />}
          {itemId === 'shyPout' && <path d="M26 35 Q32 30 38 35" fill="none" stroke={LINE} strokeWidth="2.5" strokeLinecap="round" />}
          {itemId === 'winkSmile' && <path d="M24 34 Q34 38 41 29" fill="none" stroke={LINE} strokeWidth="2.5" strokeLinecap="round" />}
        </g>
      )}

      {kind === 'blush' && (
        <g>
          <ellipse cx="32" cy="32" rx="22" ry="16" fill="#FFF2ED" stroke="#EAD7D0" strokeWidth="1.5" />
          {itemId === 'softOval' && <ellipse cx="32" cy="33" rx="12" ry="6.5" fill="#F79AB4" opacity="0.7" />}
          {itemId === 'peachDust' && <ellipse cx="32" cy="33" rx="12" ry="6.5" fill="#F8A88D" opacity="0.7" />}
          {itemId === 'heartCheek' && (
            <path d="M32 30 C28 24 22 28 26 34 L32 40 L38 34 C42 28 36 24 32 30 Z" fill="#EB7B9D" />
          )}
          {itemId === 'freckles' && (
            <g fill="#B37D6A">
              <circle cx="24" cy="32" r="2" />
              <circle cx="32" cy="35" r="2" />
              <circle cx="40" cy="31" r="2" />
            </g>
          )}
        </g>
      )}

      {kind === 'hair' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          {itemId === 'bobBuns' && (
            <>
              <circle cx="16" cy="20" r="8" fill={hair.highlight} />
              <circle cx="48" cy="20" r="8" fill={hair.highlight} />
              <path d="M16 24 C12 36 14 48 20 50 L44 50 C50 48 52 36 48 24 C44 12 20 12 16 24 Z" fill={hair.base} />
            </>
          )}
          {itemId === 'himeLong' && (
            <path d="M14 22 C12 34 12 48 16 54 L48 54 C52 48 52 34 50 22 C46 10 18 10 14 22 Z" fill={hair.base} />
          )}
          {itemId === 'twinTails' && (
            <>
              <path d="M16 22 C8 28 8 46 14 54 L22 44 Z" fill={hair.base} />
              <path d="M48 22 C56 28 56 46 50 54 L42 44 Z" fill={hair.base} />
              <circle cx="32" cy="26" r="14" fill={hair.base} />
            </>
          )}
          {itemId === 'fluffyPuff' && (
            <>
              <circle cx="14" cy="28" r="10" fill={hair.base} />
              <circle cx="50" cy="28" r="10" fill={hair.base} />
              <circle cx="32" cy="26" r="14" fill={hair.highlight} />
            </>
          )}
          {itemId === 'sidePony' && (
            <>
              <path d="M44 20 C56 24 58 44 48 54 L40 40 Z" fill={hair.base} />
              <circle cx="30" cy="28" r="14" fill={hair.base} />
            </>
          )}
          {itemId === 'wolfBob' && (
            <path d="M14 26 L12 48 L22 44 L28 52 L36 52 L42 44 L52 48 L50 26 C46 10 18 10 14 26 Z" fill={hair.base} />
          )}
          {itemId === 'braidCrown' && (
            <>
              <circle cx="32" cy="26" r="15" fill={hair.base} />
              <circle cx="18" cy="44" r="5" fill={hair.base} />
              <circle cx="46" cy="44" r="5" fill={hair.base} />
              <path d="M18 22 Q32 14 46 22" fill="none" stroke={hair.highlight} strokeWidth="4" />
            </>
          )}
          {itemId === 'curlyWaves' && (
            <path d="M16 18 C10 28 12 42 18 52 L46 52 C52 42 54 28 48 18 C42 10 22 10 16 18 Z" fill={hair.base} />
          )}
        </g>
      )}

      {kind === 'dress' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          {itemId === 'capeletBow' && (
            <>
              <path d="M22 28 L42 28 L50 52 Q32 58 14 52 Z" fill={dressCol.base} />
              <path d="M22 14 L42 14 L52 34 Q32 40 12 34 Z" fill={dressCol.highlight} />
            </>
          )}
          {itemId === 'strawberryLolita' && (
            <>
              <path d="M22 14 L42 14 L52 52 Q32 58 12 52 Z" fill={dressCol.base} />
              <rect x="26" y="16" width="12" height="16" fill="#FFFFFF" />
            </>
          )}
          {itemId === 'maidFrill' && (
            <>
              <path d="M22 14 L42 14 L52 52 Q32 58 12 52 Z" fill={dressCol.base} />
              <path d="M25 18 L39 18 L44 50 Q32 54 20 50 Z" fill="#FFFFFF" />
            </>
          )}
          {itemId === 'starlightGown' && (
            <>
              <path d="M24 14 L40 14 L54 54 Q32 60 10 54 Z" fill={dressCol.base} />
              <path d="M32 32 L34 37 L39 38 L35 41 L36 46 L32 43 L28 46 L29 41 L25 38 L30 37 Z" fill="#FBE8AC" stroke="none" />
            </>
          )}
          {itemId === 'academySet' && (
            <>
              <path d="M20 14 L44 14 L44 34 L20 34 Z" fill={dressCol.base} />
              <path d="M20 34 L44 34 L50 52 L14 52 Z" fill={dressCol.shade} />
              <path d="M27 14 L32 26 L37 14 Z" fill="#FFFFFF" />
            </>
          )}
          {itemId === 'cozyPajama' && (
            <path d="M20 14 L44 14 L48 52 Q32 56 16 52 Z" fill={dressCol.base} />
          )}
        </g>
      )}

      {kind === 'top' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          <path d="M20 16 L10 26 L16 34 L22 28 L22 48 L42 48 L42 28 L48 34 L54 26 L44 16 Z" fill={topCol.base} />
          {itemId === 'peterPanBlouse' && <path d="M24 16 Q32 26 40 16 Z" fill={topCol.highlight} />}
          {itemId === 'sailorTop' && <path d="M22 16 L32 28 L42 16 Z" fill={topCol.shade} />}
          {itemId === 'knitCardigan' && <line x1="32" y1="22" x2="32" y2="48" stroke={LINE} strokeWidth="2" />}
        </g>
      )}

      {kind === 'bottom' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          {(itemId === 'pleatedSkirt' || itemId === 'tieredRuffle' || itemId === 'pinaforeSkirt') && (
            <path d="M20 18 L44 18 L52 48 Q32 54 12 48 Z" fill={bottomCol.base} />
          )}
          {(itemId === 'denimShorts' || itemId === 'highTrousers') && (
            <path d="M18 16 L46 16 L48 50 L34 50 L32 32 L30 50 L16 50 Z" fill={bottomCol.base} />
          )}
          {itemId === 'cozyBloomers' && (
            <path d="M18 20 L46 20 C52 32 50 48 40 48 C34 48 32 40 32 40 C32 40 30 48 24 48 C14 48 12 32 18 20 Z" fill={bottomCol.highlight} />
          )}
        </g>
      )}

      {kind === 'sock' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          <path d="M24 14 L38 14 L38 42 C38 48 46 48 46 52 L24 52 Z" fill={sockCol.base} />
          {itemId === 'stripedOverKnee' && (
            <>
              <line x1="25" y1="20" x2="37" y2="20" stroke={sockCol.shade} strokeWidth="3" />
              <line x1="25" y1="27" x2="37" y2="27" stroke={sockCol.shade} strokeWidth="3" />
            </>
          )}
        </g>
      )}

      {kind === 'shoe' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          <path d="M16 30 L34 30 L38 40 C48 40 50 48 44 50 L16 50 Z" fill={shoeCol.base} />
          {itemId === 'bowMaryJanes' && <circle cx="32" cy="34" r="3.5" fill={shoeCol.highlight} />}
          {itemId === 'starSneakers' && <rect x="16" y="46" width="32" height="5" rx="2" fill="#FFFFFF" />}
        </g>
      )}

      {kind === 'headwear' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          {itemId === 'twinFlowerBows' && (
            <g transform="translate(32 32)">
              <path d="M-18 -8 L0 0 L-18 10 Z" fill={headCol.base} />
              <path d="M18 -8 L0 0 L18 10 Z" fill={headCol.base} />
              <circle cx="0" cy="0" r="5" fill="#FFFFFF" />
            </g>
          )}
          {itemId === 'fluffyBeret' && <ellipse cx="32" cy="34" rx="20" ry="11" fill={headCol.base} />}
          {itemId === 'catEars' && (
            <>
              <path d="M14 44 L20 18 L30 38 Z" fill={headCol.base} />
              <path d="M50 44 L44 18 L34 38 Z" fill={headCol.base} />
            </>
          )}
          {itemId === 'crownTiara' && <path d="M14 42 L14 24 L24 32 L32 18 L40 32 L50 24 L50 42 Z" fill={headCol.base} />}
          {itemId === 'sailorCap' && (
            <>
              <path d="M18 36 C18 20 46 20 46 36 Z" fill={headCol.highlight} />
              <rect x="14" y="34" width="36" height="8" rx="4" fill={headCol.base} />
            </>
          )}
          {itemId === 'bunnyEars' && (
            <>
              <ellipse cx="24" cy="32" rx="6" ry="18" fill={headCol.highlight} />
              <ellipse cx="40" cy="32" rx="6" ry="18" fill={headCol.highlight} />
            </>
          )}
          {itemId === 'pearlHeadband' && <path d="M14 42 Q32 18 50 42" fill="none" stroke={headCol.base} strokeWidth="5" strokeLinecap="round" />}
          {itemId === 'witchHat' && (
            <>
              <ellipse cx="32" cy="44" rx="22" ry="6" fill={headCol.base} />
              <path d="M20 42 L32 14 L44 42 Z" fill={headCol.base} />
            </>
          )}
        </g>
      )}

      {kind === 'eyewear' && (
        <g stroke={LINE} strokeWidth="2" fill="none">
          <circle cx="21" cy="32" r="9" fill="#FFFFFF" fillOpacity="0.4" />
          <circle cx="43" cy="32" r="9" fill="#FFFFFF" fillOpacity="0.4" />
          <line x1="30" y1="32" x2="34" y2="32" />
        </g>
      )}

      {kind === 'neckwear' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          {itemId === 'giantRibbon' && (
            <g transform="translate(32 30)">
              <path d="M-16 -8 L0 0 L-16 10 Z" fill={neckCol.base} />
              <path d="M16 -8 L0 0 L16 10 Z" fill={neckCol.base} />
              <circle cx="0" cy="0" r="5" fill="#E8E4EC" />
            </g>
          )}
          {itemId === 'pearlChoker' && (
            <>
              <path d="M14 32 Q32 40 50 32" fill="none" stroke={neckCol.shade} strokeWidth="4" />
              <circle cx="32" cy="36" r="4" fill="#FFFFFF" />
            </>
          )}
          {itemId === 'cozyScarf' && <rect x="14" y="24" width="36" height="14" rx="6" fill={neckCol.base} />}
          {itemId === 'bellCollar' && (
            <>
              <path d="M16 28 Q32 38 48 28" fill="none" stroke={neckCol.base} strokeWidth="4" />
              <circle cx="32" cy="38" r="5" fill="#FBE8AC" />
            </>
          )}
        </g>
      )}

      {kind === 'backItem' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          <path d="M28 32 C12 14 8 28 16 42 Z" fill={backCol.base} />
          <path d="M36 32 C52 14 56 28 48 42 Z" fill={backCol.base} />
        </g>
      )}

      {kind === 'companion' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          {itemId === 'creamLamb' && (
            <>
              <circle cx="32" cy="34" r="14" fill="#FFFDF7" />
              <ellipse cx="32" cy="35" rx="9" ry="7" fill="#FFF4DC" />
              <circle cx="29" cy="34" r="1.4" fill={LINE} stroke="none" />
              <circle cx="35" cy="34" r="1.4" fill={LINE} stroke="none" />
            </>
          )}
          {itemId === 'bobaCup' && (
            <>
              <path d="M22 22 L42 22 L39 50 L25 50 Z" fill="#F8D8E4" />
              <rect x="33" y="12" width="4" height="12" fill="#C84B78" />
            </>
          )}
          {itemId === 'magicWand' && (
            <>
              <line x1="32" y1="26" x2="32" y2="54" stroke="#F7C6D7" strokeWidth="4" />
              <path d="M32 10 L36 20 L46 21 L38 28 L40 38 L32 33 L24 38 L26 28 L18 21 L28 20 Z" fill="#FBE8AC" />
            </>
          )}
          {itemId === 'plushBear' && (
            <>
              <circle cx="21" cy="21" r="6" fill="#DFBA98" />
              <circle cx="43" cy="21" r="6" fill="#DFBA98" />
              <circle cx="32" cy="34" r="14" fill="#DFBA98" />
            </>
          )}
          {itemId === 'ribbonTote' && (
            <>
              <path d="M24 26 C24 14 40 14 40 26" fill="none" />
              <rect x="18" y="26" width="28" height="24" rx="4" fill="#FBF6F8" />
            </>
          )}
          {itemId === 'starLantern' && (
            <>
              <rect x="20" y="20" width="24" height="30" rx="6" fill="#FFF7D6" stroke="#D1A64F" />
              <circle cx="32" cy="35" r="5" fill="#F6C85F" stroke="none" />
            </>
          )}
        </g>
      )}

      {kind === 'backdrop' && (
        <g>
          <rect
            x="10"
            y="10"
            width="44"
            height="44"
            rx="8"
            fill={
              itemId === 'atelierCream'
                ? '#F2ECE8'
                : itemId === 'sakuraGarden'
                ? '#FDEEF3'
                : itemId === 'starryNight'
                ? '#2E2947'
                : itemId === 'pastelBoutique'
                ? '#F9E5EC'
                : itemId === 'cloudMeadow'
                ? '#D7EEFF'
                : '#EFE4DB'
            }
            stroke="#DFD5D9"
            strokeWidth="2"
          />
          {itemId === 'starryNight' && <circle cx="38" cy="22" r="5" fill="#FCE8A6" />}
          {itemId === 'sakuraGarden' && <circle cx="32" cy="32" r="7" fill="#F7B7CC" />}
          {itemId === 'cloudMeadow' && <rect x="10" y="38" width="44" height="16" rx="4" fill="#D5EBCE" />}
        </g>
      )}
    </svg>
  );
};
