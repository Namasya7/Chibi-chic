import React, { useId } from 'react';
import {
  EYE_COLORS,
  GARMENT_COLORS,
  HAIR_COLORS,
  SKIN_TONES,
  resolveColor,
} from '../data/wardrobeCatalog';
import { ChibiOutfit } from '../types/wardrobe';

interface ChibiStageSvgProps {
  outfit: ChibiOutfit;
  className?: string;
  includeBackdrop?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

const LINE = '#4B3644';

export const ChibiStageSvg: React.FC<ChibiStageSvgProps> = ({
  outfit,
  className = '',
  includeBackdrop = true,
  svgRef,
}) => {
  const uid = useId().replace(/:/g, '');
  const skin = SKIN_TONES[outfit.skinTone] ?? SKIN_TONES.porcelain;
  const hair = resolveColor(HAIR_COLORS, outfit.hairColor);
  const eye = resolveColor(EYE_COLORS, outfit.eyeColor);
  const dressCol = resolveColor(GARMENT_COLORS, outfit.dressColor, 0);
  const dressAcc = resolveColor(GARMENT_COLORS, outfit.dressAccent, 2);
  const topCol = resolveColor(GARMENT_COLORS, outfit.topColor, 0);
  const bottomCol = resolveColor(GARMENT_COLORS, outfit.bottomColor, 1);
  const socksCol = resolveColor(GARMENT_COLORS, outfit.socksColor, 0);
  const shoesCol = resolveColor(GARMENT_COLORS, outfit.shoesColor, 1);
  const headCol = resolveColor(GARMENT_COLORS, outfit.headwearColor, 1);
  const neckCol = resolveColor(GARMENT_COLORS, outfit.neckwearColor, 2);
  const backCol = resolveColor(GARMENT_COLORS, outfit.backItemColor, 0);

  const hasDress = outfit.dress !== 'none';

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 400 520"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Customized Chibi Chic character"
    >
      <defs>
        <linearGradient id={`iris-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={eye.shade} />
          <stop offset="52%" stopColor={eye.base} />
          <stop offset="100%" stopColor={eye.highlight} />
        </linearGradient>

        <linearGradient id={`hair-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={hair.highlight} />
          <stop offset="45%" stopColor={hair.base} />
          <stop offset="100%" stopColor={hair.shade} />
        </linearGradient>

        <linearGradient id={`dress-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={dressCol.highlight} />
          <stop offset="55%" stopColor={dressCol.base} />
          <stop offset="100%" stopColor={dressCol.shade} />
        </linearGradient>

        <linearGradient id={`fairy-${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={backCol.highlight} stopOpacity="0.88" />
          <stop offset="50%" stopColor={backCol.base} stopOpacity="0.72" />
          <stop offset="100%" stopColor="#F8D8EA" stopOpacity="0.82" />
        </linearGradient>

        <radialGradient id={`cheek-${uid}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#F79AB4" stopOpacity="0.58" />
          <stop offset="100%" stopColor="#F79AB4" stopOpacity="0" />
        </radialGradient>

        <linearGradient id={`nightSky-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#26243D" />
          <stop offset="65%" stopColor="#3B355C" />
          <stop offset="100%" stopColor="#584C78" />
        </linearGradient>

        <linearGradient id={`meadowSky-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#D7EEFF" />
          <stop offset="70%" stopColor="#F5FAFF" />
          <stop offset="100%" stopColor="#E1F2DF" />
        </linearGradient>

        <linearGradient id={`sakuraBg-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FDEEF3" />
          <stop offset="70%" stopColor="#FFF8FA" />
          <stop offset="100%" stopColor="#F3E5E9" />
        </linearGradient>
      </defs>

      {/* LAYER 1: BACKDROP SCENE */}
      {includeBackdrop && (
        <g>
          {outfit.backdrop === 'atelierCream' && (
            <>
              <rect width="400" height="520" fill="#FAF7F4" />
              <circle cx="200" cy="245" r="158" fill="#F2ECE8" opacity="0.75" />
              <circle cx="200" cy="245" r="142" fill="none" stroke="#E5DCD5" strokeWidth="1.5" strokeDasharray="5 6" />
              <ellipse cx="200" cy="466" rx="88" ry="13" fill="#E8DFD9" />
            </>
          )}

          {outfit.backdrop === 'sakuraGarden' && (
            <>
              <rect width="400" height="520" fill={`url(#sakuraBg-${uid})`} />
              <path d="M0 430 Q120 410 240 432 T400 422 L400 520 L0 520 Z" fill="#EFE0E5" />
              <path d="M-10 55 Q65 80 125 45" stroke="#8C6A73" strokeWidth="7" strokeLinecap="round" fill="none" />
              <circle cx="52" cy="58" r="24" fill="#F7C7D7" opacity="0.7" />
              <circle cx="88" cy="46" r="20" fill="#FADCE6" opacity="0.85" />
              <circle cx="22" cy="76" r="18" fill="#F4B8CD" opacity="0.65" />
              <circle cx="344" cy="78" r="22" fill="#F7C7D7" opacity="0.65" />
              <circle cx="316" cy="54" r="17" fill="#FADCE6" opacity="0.8" />
              {/* Drifting petals */}
              <ellipse cx="95" cy="145" rx="6" ry="3.5" transform="rotate(-24 95 145)" fill="#F7B7CC" />
              <ellipse cx="322" cy="188" rx="5.5" ry="3" transform="rotate(30 322 188)" fill="#F7B7CC" />
              <ellipse cx="70" cy="290" rx="5" ry="3" transform="rotate(18 70 290)" fill="#F9CAD9" />
              <ellipse cx="338" cy="316" rx="6" ry="3.5" transform="rotate(-18 338 316)" fill="#F7B7CC" />
            </>
          )}

          {outfit.backdrop === 'starryNight' && (
            <>
              <rect width="400" height="520" fill={`url(#nightSky-${uid})`} />
              {/* Crescent Moon */}
              <path d="M324 52 A28 28 0 1 0 352 94 A22 22 0 1 1 324 52 Z" fill="#FCE8A6" />
              {/* Twinkling stars */}
              <path d="M68 78 L71 86 L79 89 L71 92 L68 100 L65 92 L57 89 L65 86 Z" fill="#FFF3C4" />
              <path d="M342 156 L344 162 L350 164 L344 166 L342 172 L340 166 L334 164 L340 162 Z" fill="#FFF3C4" />
              <circle cx="114" cy="58" r="2.2" fill="#FFFFFF" opacity="0.8" />
              <circle cx="272" cy="52" r="2" fill="#FFFFFF" opacity="0.7" />
              <circle cx="52" cy="195" r="1.8" fill="#FFFFFF" opacity="0.65" />
              <circle cx="354" cy="245" r="2.2" fill="#FFFFFF" opacity="0.75" />
              <circle cx="92" cy="328" r="1.8" fill="#FFFFFF" opacity="0.6" />
              {/* Balcony floor */}
              <rect x="0" y="438" width="400" height="82" fill="#2E2947" />
              <line x1="0" y1="438" x2="400" y2="438" stroke="#6E6496" strokeWidth="2" />
            </>
          )}

          {outfit.backdrop === 'pastelBoutique' && (
            <>
              <rect width="400" height="520" fill="#FDF6F8" />
              <rect x="28" y="24" width="344" height="472" rx="20" fill="#FFFDFD" stroke="#EAD9E0" strokeWidth="2" />
              <path d="M28 74 Q110 98 200 74 Q290 98 372 74 L372 24 L28 24 Z" fill="#F9E5EC" />
              <rect x="28" y="432" width="344" height="64" rx="0" fill="#F5EBF0" />
              <line x1="28" y1="432" x2="372" y2="432" stroke="#E5D3DC" strokeWidth="1.5" />
            </>
          )}

          {outfit.backdrop === 'cloudMeadow' && (
            <>
              <rect width="400" height="520" fill={`url(#meadowSky-${uid})`} />
              <g fill="#FFFFFF" opacity="0.92">
                <circle cx="72" cy="104" r="26" />
                <circle cx="98" cy="96" r="32" />
                <circle cx="128" cy="108" r="24" />
                <circle cx="298" cy="84" r="24" />
                <circle cx="326" cy="78" r="30" />
                <circle cx="352" cy="90" r="22" />
              </g>
              <path d="M0 434 Q100 412 200 430 Q300 448 400 424 L400 520 L0 520 Z" fill="#D5EBCE" />
              <circle cx="64" cy="458" r="4" fill="#FFF8CE" />
              <circle cx="332" cy="466" r="4" fill="#FAD7E4" />
              <circle cx="305" cy="450" r="3.5" fill="#FFF8CE" />
            </>
          )}

          {outfit.backdrop === 'checkeredCafe' && (
            <>
              <rect width="400" height="520" fill="#FAF5EF" />
              <rect x="0" y="0" width="400" height="424" fill="#FCF8F4" />
              {/* Subtle vertical café wainscot stripes */}
              <g stroke="#EFE5DC" strokeWidth="1.5">
                <line x1="50" y1="0" x2="50" y2="424" />
                <line x1="100" y1="0" x2="100" y2="424" />
                <line x1="150" y1="0" x2="150" y2="424" />
                <line x1="250" y1="0" x2="250" y2="424" />
                <line x1="300" y1="0" x2="300" y2="424" />
                <line x1="350" y1="0" x2="350" y2="424" />
              </g>
              <rect x="0" y="424" width="400" height="96" fill="#EFE4DB" />
              {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
                <rect
                  key={i}
                  x={i * 50}
                  y={424 + (i % 2 === 0 ? 0 : 24)}
                  width="50"
                  height="24"
                  fill="#E3D4C8"
                />
              ))}
              {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
                <rect
                  key={`b-${i}`}
                  x={i * 50}
                  y={472 + (i % 2 === 0 ? 0 : 24)}
                  width="50"
                  height="24"
                  fill="#E3D4C8"
                />
              ))}
              <line x1="0" y1="424" x2="400" y2="424" stroke="#D7C3B4" strokeWidth="2" />
            </>
          )}
        </g>
      )}

      {/* Ground shadow under doll */}
      <ellipse cx="200" cy="468" rx="58" ry="9" fill={outfit.backdrop === 'starryNight' ? '#1C1830' : '#D9CCD2'} opacity="0.55" />

      {/* LAYER 2: BACK ITEMS (WINGS / RIBBON CAPE) */}
      {outfit.backItem === 'angelWings' && (
        <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
          <path
            d="M174 268 C118 228 74 242 78 282 C80 302 104 310 118 308 C100 322 104 342 126 342 C142 342 158 326 174 302 Z"
            fill={backCol.highlight}
          />
          <path
            d="M226 268 C282 228 326 242 322 282 C320 302 296 310 282 308 C300 322 296 342 274 342 C258 342 242 326 226 302 Z"
            fill={backCol.highlight}
          />
          <path d="M120 278 Q144 282 162 292" fill="none" stroke={backCol.shade} strokeWidth="2" />
          <path d="M280 278 Q256 282 238 292" fill="none" stroke={backCol.shade} strokeWidth="2" />
        </g>
      )}

      {outfit.backItem === 'batWings' && (
        <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
          <path
            d="M174 274 L88 228 Q106 270 84 294 Q112 298 118 322 Q144 308 174 316 Z"
            fill={backCol.base === '#FBF9FC' ? '#3D3542' : backCol.base}
          />
          <path
            d="M226 274 L312 228 Q294 270 316 294 Q288 298 282 322 Q256 308 226 316 Z"
            fill={backCol.base === '#FBF9FC' ? '#3D3542' : backCol.base}
          />
        </g>
      )}

      {outfit.backItem === 'fairyWings' && (
        <g stroke={LINE} strokeWidth="2" strokeLinejoin="round">
          <path
            d="M174 270 C112 204 68 222 86 272 C96 296 138 296 174 292 Z"
            fill={`url(#fairy-${uid})`}
          />
          <path
            d="M174 294 C122 304 102 342 126 356 C148 368 166 338 176 312 Z"
            fill={`url(#fairy-${uid})`}
          />
          <path
            d="M226 270 C288 204 332 222 314 272 C304 296 262 296 226 292 Z"
            fill={`url(#fairy-${uid})`}
          />
          <path
            d="M226 294 C278 304 298 342 274 356 C252 368 234 338 224 312 Z"
            fill={`url(#fairy-${uid})`}
          />
          <path d="M108 258 Q138 268 164 282" fill="none" stroke="#FFFFFF" strokeWidth="1.8" opacity="0.8" />
          <path d="M292 258 Q262 268 236 282" fill="none" stroke="#FFFFFF" strokeWidth="1.8" opacity="0.8" />
        </g>
      )}

      {outfit.backItem === 'ribbonCape' && (
        <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
          <path d="M174 300 L118 358 Q142 368 166 344 Z" fill={backCol.base} />
          <path d="M226 300 L282 358 Q258 368 234 344 Z" fill={backCol.base} />
          <path d="M176 288 C134 264 114 296 144 318 C158 326 172 316 178 304 Z" fill={backCol.highlight} />
          <path d="M224 288 C266 264 286 296 256 318 C242 326 228 316 222 304 Z" fill={backCol.highlight} />
        </g>
      )}

      {/* LAYER 3: BACK HAIR */}
      <g stroke={LINE} strokeWidth="2.6" strokeLinejoin="round">
        {outfit.hairStyle === 'bobBuns' && (
          <>
            <path
              d="M116 154 C92 184 88 232 108 256 C122 268 138 256 146 244 L254 244 C262 256 278 268 292 256 C312 232 308 184 284 154 Z"
              fill={`url(#hair-${uid})`}
            />
            {/* Twin Fluffy Hair Buns */}
            <circle cx="122" cy="116" r="24" fill={hair.highlight} />
            <circle cx="278" cy="116" r="24" fill={hair.highlight} />
          </>
        )}

        {outfit.hairStyle === 'himeLong' && (
          <path
            d="M112 138 C98 200 100 295 114 358 C142 372 258 372 286 358 C300 295 302 200 288 138 Z"
            fill={`url(#hair-${uid})`}
          />
        )}

        {outfit.hairStyle === 'twinTails' && (
          <>
            <path d="M120 132 C80 144 68 214 82 284 C94 298 118 288 122 256 C124 224 122 178 132 150 Z" fill={`url(#hair-${uid})`} />
            <path d="M280 132 C320 144 332 214 318 284 C306 298 282 288 278 256 C276 224 278 178 268 150 Z" fill={`url(#hair-${uid})`} />
            <circle cx="122" cy="138" r="10" fill={dressAcc.base} />
            <circle cx="278" cy="138" r="10" fill={dressAcc.base} />
          </>
        )}

        {outfit.hairStyle === 'fluffyPuff' && (
          <>
            <circle cx="110" cy="138" r="34" fill={`url(#hair-${uid})`} />
            <circle cx="104" cy="166" r="24" fill={hair.base} />
            <circle cx="290" cy="138" r="34" fill={`url(#hair-${uid})`} />
            <circle cx="296" cy="166" r="24" fill={hair.base} />
          </>
        )}

        {outfit.hairStyle === 'sidePony' && (
          <>
            <path d="M266 132 C314 142 330 220 310 292 C292 300 272 278 272 246 C272 210 264 174 256 152 Z" fill={`url(#hair-${uid})`} />
            <path d="M114 148 C108 192 114 232 132 246 L268 246 C282 232 286 192 282 148 Z" fill={hair.shade} />
            <circle cx="270" cy="138" r="9" fill={dressAcc.base} />
          </>
        )}

        {outfit.hairStyle === 'wolfBob' && (
          <path
            d="M114 150 C96 184 94 242 118 268 L138 248 L152 272 L248 272 L262 248 L282 268 C306 242 304 184 286 150 Z"
            fill={`url(#hair-${uid})`}
          />
        )}

        {outfit.hairStyle === 'braidCrown' && (
          <>
            <path d="M114 152 C104 204 114 248 134 264 L266 264 C286 248 296 204 286 152 Z" fill={`url(#hair-${uid})`} />
            <circle cx="122" cy="240" r="12" fill={hair.base} />
            <circle cx="126" cy="260" r="10" fill={hair.base} />
            <circle cx="130" cy="278" r="8" fill={hair.shade} />
            <circle cx="278" cy="240" r="12" fill={hair.base} />
            <circle cx="274" cy="260" r="10" fill={hair.base} />
            <circle cx="270" cy="278" r="8" fill={hair.shade} />
          </>
        )}

        {outfit.hairStyle === 'curlyWaves' && (
          <path
            d="M110 142 C86 182 94 224 106 248 C88 274 96 318 118 338 C134 354 154 348 164 334 L236 334 C246 348 266 354 282 338 C304 318 312 274 294 248 C306 224 314 182 290 142 Z"
            fill={`url(#hair-${uid})`}
          />
        )}
      </g>

      {/* LAYER 4: CHIBI BODY BASE (ARMS, TORSO, NECK, LEGS) */}
      <g>
        {/* Neck */}
        <rect x="190" y="232" width="20" height="24" fill={skin.base} stroke={LINE} strokeWidth="2.4" />
        <path d="M191 236 Q200 246 209 236 L209 242 Q200 250 191 242 Z" fill={skin.shade} />

        {/* Left & Right Arms */}
        <path
          d="M174 262 C154 276 142 302 138 320 C134 328 140 335 147 334 C153 333 157 326 160 318 C165 304 174 288 182 276 Z"
          fill={skin.base}
          stroke={LINE}
          strokeWidth="2.4"
          strokeLinejoin="round"
        />
        <path
          d="M226 262 C246 276 258 302 262 320 C266 328 260 335 253 334 C247 333 243 326 240 318 C235 304 226 288 218 276 Z"
          fill={skin.base}
          stroke={LINE}
          strokeWidth="2.4"
          strokeLinejoin="round"
        />

        {/* Petite Torso */}
        <path
          d="M174 256 Q200 248 226 256 L232 334 Q200 344 168 334 Z"
          fill={skin.base}
          stroke={LINE}
          strokeWidth="2.4"
          strokeLinejoin="round"
        />

        {/* Undergarment modesty singlet when shirtless */}
        {!hasDress && outfit.top === 'none' && (
          <path
            d="M178 260 L186 260 L188 274 Q200 280 212 274 L214 260 L222 260 L228 322 Q200 328 172 322 Z"
            fill="#FFFFFF"
            stroke={LINE}
            strokeWidth="2"
          />
        )}
        {!hasDress && outfit.bottom === 'none' && (
          <path
            d="M172 322 Q200 328 228 322 L226 344 Q200 352 174 344 Z"
            fill="#F9EFF4"
            stroke={LINE}
            strokeWidth="2"
          />
        )}

        {/* Legs */}
        <path
          d="M172 334 C170 374 172 418 176 446 C178 456 196 456 196 444 C197 416 198 378 199 342 Z"
          fill={skin.base}
          stroke={LINE}
          strokeWidth="2.4"
          strokeLinejoin="round"
        />
        <path
          d="M228 334 C230 374 228 418 224 446 C222 456 204 456 204 444 C203 416 202 378 201 342 Z"
          fill={skin.base}
          stroke={LINE}
          strokeWidth="2.4"
          strokeLinejoin="round"
        />
        {/* Soft knee blush */}
        <ellipse cx="185" cy="396" rx="6" ry="3.5" fill={skin.shade} opacity="0.55" />
        <ellipse cx="215" cy="396" rx="6" ry="3.5" fill={skin.shade} opacity="0.55" />
      </g>

      {/* LAYER 5: SOCKS & LEGWEAR */}
      <g>
        {outfit.socks === 'ankleFrill' && (
          <g stroke={LINE} strokeWidth="2.2" strokeLinejoin="round">
            <path d="M174 422 Q185 426 196 422 L196 450 Q186 456 175 450 Z" fill={socksCol.base} />
            <path d="M204 422 Q215 426 226 422 L225 450 Q214 456 204 450 Z" fill={socksCol.base} />
            <path d="M172 422 Q178 416 185 422 Q192 416 198 422" fill="none" stroke={socksCol.highlight} strokeWidth="3.5" />
            <path d="M202 422 Q208 416 215 422 Q222 416 228 422" fill="none" stroke={socksCol.highlight} strokeWidth="3.5" />
          </g>
        )}

        {outfit.socks === 'kneeRibbon' && (
          <g stroke={LINE} strokeWidth="2.2" strokeLinejoin="round">
            <path d="M172 388 Q185 394 197 388 L196 450 Q186 456 175 450 Z" fill={socksCol.base} />
            <path d="M203 388 Q215 394 228 388 L225 450 Q214 456 204 450 Z" fill={socksCol.base} />
            {/* Tiny sock cuff bows */}
            <circle cx="176" cy="392" r="3.5" fill={shoesCol.base} />
            <circle cx="224" cy="392" r="3.5" fill={shoesCol.base} />
          </g>
        )}

        {outfit.socks === 'stripedOverKnee' && (
          <g stroke={LINE} strokeWidth="2.2" strokeLinejoin="round">
            <path d="M172 366 Q185 372 198 366 L196 450 Q186 456 175 450 Z" fill={socksCol.base} />
            <path d="M202 366 Q215 372 228 366 L225 450 Q214 456 204 450 Z" fill={socksCol.base} />
            <line x1="173" y1="376" x2="197" y2="376" stroke={socksCol.shade} strokeWidth="4" />
            <line x1="173" y1="386" x2="197" y2="386" stroke={socksCol.shade} strokeWidth="4" />
            <line x1="203" y1="376" x2="227" y2="376" stroke={socksCol.shade} strokeWidth="4" />
            <line x1="203" y1="386" x2="227" y2="386" stroke={socksCol.shade} strokeWidth="4" />
          </g>
        )}

        {outfit.socks === 'laceTights' && (
          <g>
            <path d="M172 338 L199 342 L196 450 Q186 456 175 450 Z" fill={socksCol.base} opacity="0.58" stroke={LINE} strokeWidth="2" />
            <path d="M228 338 L201 342 L204 450 Q214 456 225 450 Z" fill={socksCol.base} opacity="0.58" stroke={LINE} strokeWidth="2" />
            {[362, 382, 402, 422].map((y) => (
              <React.Fragment key={y}>
                <circle cx="185" cy={y} r="1.8" fill={socksCol.highlight} />
                <circle cx="215" cy={y} r="1.8" fill={socksCol.highlight} />
              </React.Fragment>
            ))}
          </g>
        )}

        {outfit.socks === 'fluffyWarmers' && (
          <g stroke={LINE} strokeWidth="2.2" strokeLinejoin="round">
            <path d="M170 398 Q184 392 198 398 L199 448 Q184 454 169 448 Z" fill={socksCol.highlight} />
            <path d="M202 398 Q216 392 230 398 L231 448 Q216 454 201 448 Z" fill={socksCol.highlight} />
            <path d="M170 400 Q177 394 184 400 Q191 394 198 400" fill="none" stroke={socksCol.shade} strokeWidth="2" />
            <path d="M202 400 Q209 394 216 400 Q223 394 230 400" fill="none" stroke={socksCol.shade} strokeWidth="2" />
          </g>
        )}
      </g>

      {/* LAYER 6: SHOES */}
      <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
        {outfit.shoes === 'bowMaryJanes' && (
          <>
            <path d="M172 444 C170 462 198 464 198 450 L196 440 Q184 446 172 444 Z" fill={shoesCol.base} />
            <path d="M228 444 C230 462 202 464 202 450 L204 440 Q216 446 228 444 Z" fill={shoesCol.base} />
            <line x1="173" y1="442" x2="196" y2="442" stroke={LINE} strokeWidth="2.2" />
            <line x1="204" y1="442" x2="227" y2="442" stroke={LINE} strokeWidth="2.2" />
            <circle cx="185" cy="442" r="3.8" fill={shoesCol.highlight} />
            <circle cx="215" cy="442" r="3.8" fill={shoesCol.highlight} />
          </>
        )}

        {outfit.shoes === 'platformLoafers' && (
          <>
            <path d="M171 438 L197 438 L198 456 Q184 460 170 456 Z" fill={shoesCol.base} />
            <path d="M203 438 L229 438 L230 456 Q216 460 202 456 Z" fill={shoesCol.base} />
            <rect x="170" y="454" width="28" height="6" rx="2" fill={shoesCol.shade} />
            <rect x="202" y="454" width="28" height="6" rx="2" fill={shoesCol.shade} />
            <rect x="179" y="443" width="10" height="4" rx="1.5" fill="#FBE8AC" strokeWidth="1.5" />
            <rect x="211" y="443" width="10" height="4" rx="1.5" fill="#FBE8AC" strokeWidth="1.5" />
          </>
        )}

        {outfit.shoes === 'ribbonBallet' && (
          <>
            <path d="M173 444 C172 462 197 464 197 448 Q185 452 173 444 Z" fill={shoesCol.base} />
            <path d="M227 444 C228 462 203 464 203 448 Q215 452 227 444 Z" fill={shoesCol.base} />
            <path d="M174 432 L195 442 M195 432 L174 442" stroke={shoesCol.shade} strokeWidth="2" />
            <path d="M205 432 L226 442 M226 432 L205 442" stroke={shoesCol.shade} strokeWidth="2" />
          </>
        )}

        {outfit.shoes === 'laceBoots' && (
          <>
            <path d="M171 418 L197 418 L198 458 Q184 462 170 458 Z" fill={shoesCol.base} />
            <path d="M203 418 L229 418 L230 458 Q216 462 202 458 Z" fill={shoesCol.base} />
            <line x1="178" y1="426" x2="190" y2="426" stroke={shoesCol.highlight} strokeWidth="2" />
            <line x1="178" y1="434" x2="190" y2="434" stroke={shoesCol.highlight} strokeWidth="2" />
            <line x1="178" y1="442" x2="190" y2="442" stroke={shoesCol.highlight} strokeWidth="2" />
            <line x1="210" y1="426" x2="222" y2="426" stroke={shoesCol.highlight} strokeWidth="2" />
            <line x1="210" y1="434" x2="222" y2="434" stroke={shoesCol.highlight} strokeWidth="2" />
            <line x1="210" y1="442" x2="222" y2="442" stroke={shoesCol.highlight} strokeWidth="2" />
          </>
        )}

        {outfit.shoes === 'bunnySlippers' && (
          <>
            <ellipse cx="183" cy="451" rx="16" ry="11" fill={shoesCol.highlight} />
            <ellipse cx="217" cy="451" rx="16" ry="11" fill={shoesCol.highlight} />
            <ellipse cx="177" cy="437" rx="3.5" ry="8" fill={shoesCol.highlight} />
            <ellipse cx="186" cy="437" rx="3.5" ry="8" fill={shoesCol.highlight} />
            <ellipse cx="214" cy="437" rx="3.5" ry="8" fill={shoesCol.highlight} />
            <ellipse cx="223" cy="437" rx="3.5" ry="8" fill={shoesCol.highlight} />
            <circle cx="182" cy="451" r="1.5" fill={LINE} stroke="none" />
            <circle cx="218" cy="451" r="1.5" fill={LINE} stroke="none" />
          </>
        )}

        {outfit.shoes === 'starSneakers' && (
          <>
            <path d="M170 434 L197 434 L198 456 L170 456 Z" fill={shoesCol.base} />
            <path d="M203 434 L230 434 L230 456 L202 456 Z" fill={shoesCol.base} />
            <rect x="169" y="452" width="30" height="7" rx="3" fill="#FFFFFF" />
            <rect x="201" y="452" width="30" height="7" rx="3" fill="#FFFFFF" />
            <circle cx="184" cy="444" r="3.5" fill="#FBE8AC" strokeWidth="1.5" />
            <circle cx="216" cy="444" r="3.5" fill="#FBE8AC" strokeWidth="1.5" />
          </>
        )}
      </g>

      {/* LAYER 7: BOTTOMS (ONLY WHEN NO FULL DRESS) */}
      {!hasDress && (
        <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
          {outfit.bottom === 'pleatedSkirt' && (
            <>
              <path d="M171 312 L229 312 L252 374 Q200 384 148 374 Z" fill={bottomCol.base} />
              <line x1="184" y1="316" x2="174" y2="376" stroke={LINE} strokeWidth="1.8" />
              <line x1="200" y1="316" x2="200" y2="378" stroke={LINE} strokeWidth="1.8" />
              <line x1="216" y1="316" x2="226" y2="376" stroke={LINE} strokeWidth="1.8" />
              <rect x="170" y="308" width="60" height="9" rx="3" fill={bottomCol.shade} />
            </>
          )}

          {outfit.bottom === 'tieredRuffle' && (
            <>
              <path d="M172 312 L228 312 L248 352 Q200 364 152 352 Z" fill={bottomCol.base} />
              <path d="M156 348 L244 348 L260 384 Q200 398 140 384 Z" fill={bottomCol.highlight} />
              <rect x="171" y="308" width="58" height="8" rx="3" fill={bottomCol.shade} />
            </>
          )}

          {outfit.bottom === 'denimShorts' && (
            <>
              <path d="M170 312 L230 312 L236 364 L204 364 L200 342 L196 364 L164 364 Z" fill={bottomCol.base} />
              <rect x="163" y="356" width="33" height="8" rx="2" fill={bottomCol.highlight} />
              <rect x="204" y="356" width="33" height="8" rx="2" fill={bottomCol.highlight} />
              <rect x="170" y="310" width="60" height="9" rx="2" fill={bottomCol.shade} />
            </>
          )}

          {outfit.bottom === 'cozyBloomers' && (
            <>
              <path
                d="M170 312 L230 312 C244 334 242 364 220 366 C208 367 202 356 200 348 C198 356 192 367 180 366 C158 364 156 334 170 312 Z"
                fill={bottomCol.highlight}
              />
              <path d="M164 358 Q180 368 198 358" fill="none" stroke={bottomCol.shade} strokeWidth="2.5" />
              <path d="M202 358 Q220 368 236 358" fill="none" stroke={bottomCol.shade} strokeWidth="2.5" />
            </>
          )}

          {outfit.bottom === 'highTrousers' && (
            <>
              <path d="M170 306 L230 306 L236 392 L204 392 L200 344 L196 392 L164 392 Z" fill={bottomCol.base} />
              <rect x="170" y="304" width="60" height="10" rx="2" fill={bottomCol.shade} />
              <circle cx="200" cy="309" r="2.5" fill="#FBE8AC" />
            </>
          )}

          {outfit.bottom === 'pinaforeSkirt' && (
            <>
              <path d="M172 312 L228 312 L254 378 Q200 390 146 378 Z" fill={bottomCol.base} />
              <rect x="172" y="306" width="56" height="10" rx="2" fill={bottomCol.shade} />
              <rect x="180" y="256" width="8" height="54" rx="2" fill={bottomCol.base} />
              <rect x="212" y="256" width="8" height="54" rx="2" fill={bottomCol.base} />
              <circle cx="184" cy="311" r="2.5" fill="#FBE8AC" />
              <circle cx="216" cy="311" r="2.5" fill="#FBE8AC" />
            </>
          )}
        </g>
      )}

      {/* LAYER 8: TOPS (ONLY WHEN NO FULL DRESS) */}
      {!hasDress && (
        <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
          {outfit.top === 'peterPanBlouse' && (
            <>
              {/* Sleeves */}
              <path d="M174 256 C152 270 142 296 138 314 L158 320 C165 302 174 286 180 274 Z" fill={topCol.base} />
              <path d="M226 256 C248 270 258 296 262 314 L242 320 C235 302 226 286 220 274 Z" fill={topCol.base} />
              {/* Bodice */}
              <path d="M174 256 Q200 248 226 256 L230 318 Q200 324 170 318 Z" fill={topCol.base} />
              {/* Peter Pan Collar */}
              <path d="M188 252 Q178 268 198 268 Q200 260 198 254 Z" fill={topCol.highlight} />
              <path d="M212 252 Q222 268 202 268 Q200 260 202 254 Z" fill={topCol.highlight} />
              <circle cx="200" cy="278" r="2" fill={topCol.shade} stroke="none" />
              <circle cx="200" cy="294" r="2" fill={topCol.shade} stroke="none" />
            </>
          )}

          {outfit.top === 'knitCardigan' && (
            <>
              <path d="M174 256 C150 270 140 298 136 318 L156 324 C164 306 174 286 180 274 Z" fill={topCol.base} />
              <path d="M226 256 C250 270 260 298 264 318 L244 324 C236 306 226 286 220 274 Z" fill={topCol.base} />
              <path d="M173 256 L227 256 L232 322 Q200 328 168 322 Z" fill={topCol.base} />
              <path d="M190 254 L200 284 L210 254 Z" fill="#FFFFFF" />
              <line x1="200" y1="284" x2="200" y2="324" stroke={LINE} strokeWidth="2" />
              <circle cx="195" cy="294" r="2.2" fill="#FBE8AC" strokeWidth="1.4" />
              <circle cx="195" cy="310" r="2.2" fill="#FBE8AC" strokeWidth="1.4" />
            </>
          )}

          {outfit.top === 'sailorTop' && (
            <>
              <path d="M174 256 C154 268 148 286 146 296 L166 300 C170 286 176 276 182 270 Z" fill={topCol.highlight} />
              <path d="M226 256 C246 268 252 286 254 296 L234 300 C230 286 224 276 218 270 Z" fill={topCol.highlight} />
              <path d="M174 256 L226 256 L228 318 Q200 324 172 318 Z" fill={topCol.highlight} />
              <path d="M174 256 L200 284 L226 256 L216 252 L200 268 L184 252 Z" fill={topCol.shade} />
              <path d="M190 280 L200 274 L210 280 L204 296 L200 286 L196 296 Z" fill="#D95D7E" />
            </>
          )}

          {outfit.top === 'offShoulderFrill' && (
            <>
              <path d="M172 268 Q200 274 228 268 L230 318 Q200 324 170 318 Z" fill={topCol.base} />
              <path d="M150 272 Q164 262 178 272 Q190 264 200 272 Q210 264 222 272 Q236 262 250 272 L244 290 Q200 296 156 290 Z" fill={topCol.highlight} />
            </>
          )}

          {outfit.top === 'oversizedHoodie' && (
            <>
              <path d="M172 254 C146 268 134 300 132 324 L154 330 C162 308 172 288 180 276 Z" fill={topCol.base} />
              <path d="M228 254 C254 268 266 300 268 324 L246 330 C238 308 228 288 220 276 Z" fill={topCol.base} />
              <path d="M170 254 Q200 244 230 254 L236 330 Q200 338 164 330 Z" fill={topCol.base} />
              {/* Kangaroo pocket */}
              <path d="M180 298 L220 298 L224 320 Q200 324 176 320 Z" fill={topCol.shade} />
              <line x1="194" y1="258" x2="192" y2="278" stroke={topCol.highlight} strokeWidth="2.4" strokeLinecap="round" />
              <line x1="206" y1="258" x2="208" y2="278" stroke={topCol.highlight} strokeWidth="2.4" strokeLinecap="round" />
            </>
          )}

          {outfit.top === 'sweetheartTee' && (
            <>
              <path d="M174 256 C158 266 152 282 148 292 L168 298 C172 286 176 276 182 270 Z" fill={topCol.base} />
              <path d="M226 256 C242 266 248 282 252 292 L232 298 C228 286 224 276 218 270 Z" fill={topCol.base} />
              <path d="M176 256 Q188 270 200 262 Q212 270 224 256 L228 318 Q200 324 172 318 Z" fill={topCol.base} />
              <path d="M200 286 C195 280 188 284 192 291 L200 298 L208 291 C212 284 205 280 200 286 Z" fill={topCol.highlight} />
            </>
          )}
        </g>
      )}

      {/* LAYER 9: FULL DRESSES */}
      {hasDress && (
        <g stroke={LINE} strokeWidth="2.4" strokeLinejoin="round">
          {outfit.dress === 'capeletBow' && (
            <>
              {/* Puffy lower skirt */}
              <path
                d="M168 308 L232 308 C258 338 268 380 250 398 C220 412 180 412 150 398 C132 380 142 338 168 308 Z"
                fill={`url(#dress-${uid})`}
              />
              {/* Sleeves peeking under capelet */}
              <path d="M158 286 L138 316 L158 322 L172 296 Z" fill={dressCol.base} />
              <path d="M242 286 L262 316 L242 322 L228 296 Z" fill={dressCol.base} />
              {/* Reference-inspired scalloped capelet */}
              <path
                d="M180 254 Q200 248 220 254 C244 268 258 292 266 312 Q248 320 232 312 Q216 322 200 314 Q184 322 168 312 Q152 320 134 312 C142 292 156 268 180 254 Z"
                fill={dressCol.highlight}
              />
              {/* Capelet pleat trim */}
              <path
                d="M138 306 Q200 316 262 306"
                fill="none"
                stroke={dressCol.shade}
                strokeWidth="1.8"
              />
            </>
          )}

          {outfit.dress === 'strawberryLolita' && (
            <>
              {/* Puff sleeves */}
              <circle cx="164" cy="272" r="15" fill={dressCol.highlight} />
              <circle cx="236" cy="272" r="15" fill={dressCol.highlight} />
              {/* Skirt tiers */}
              <path d="M168 310 L232 310 L264 384 Q200 404 136 384 Z" fill={dressCol.base} />
              <path d="M152 352 Q200 366 248 352 L262 384 Q200 404 138 384 Z" fill={dressCol.highlight} />
              {/* Bodice & apron bib */}
              <path d="M174 256 L226 256 L230 314 L170 314 Z" fill={dressCol.base} />
              <path d="M184 264 L216 264 L218 314 L182 314 Z" fill="#FFFFFF" />
              <circle cx="180" cy="368" r="4" fill={dressAcc.base} />
              <circle cx="200" cy="372" r="4" fill={dressAcc.base} />
              <circle cx="220" cy="368" r="4" fill={dressAcc.base} />
            </>
          )}

          {outfit.dress === 'maidFrill' && (
            <>
              <circle cx="164" cy="272" r="14" fill={dressCol.base} />
              <circle cx="236" cy="272" r="14" fill={dressCol.base} />
              <path d="M172 256 L228 256 L230 314 L170 314 Z" fill={dressCol.base} />
              <path d="M168 312 L232 312 L262 386 Q200 402 138 386 Z" fill={dressCol.base} />
              {/* Crisp white apron */}
              <path d="M184 262 L216 262 L214 314 L186 314 Z" fill="#FFFFFF" />
              <path d="M178 314 L222 314 L238 378 Q200 390 162 378 Z" fill="#FFFFFF" />
              <path d="M188 256 L200 272 L212 256" fill="none" stroke="#FFFFFF" strokeWidth="4" />
            </>
          )}

          {outfit.dress === 'starlightGown' && (
            <>
              <path d="M174 260 Q200 268 226 260 L230 314 L170 314 Z" fill={dressCol.base} />
              <path d="M170 312 L230 312 C264 344 276 402 262 426 Q200 444 138 426 C124 402 136 344 170 312 Z" fill={`url(#dress-${uid})`} />
              {/* Sheer overskirt */}
              <path d="M170 312 Q200 342 230 312 L252 376 Q200 364 148 376 Z" fill={dressCol.highlight} opacity="0.85" />
              {/* Star accents */}
              <path d="M200 332 L203 338 L210 339 L204 344 L206 350 L200 346 L194 350 L196 344 L190 339 L197 338 Z" fill={dressAcc.base} strokeWidth="1.5" />
            </>
          )}

          {outfit.dress === 'academySet' && (
            <>
              <path d="M174 256 C152 268 142 296 138 316 L158 322 C165 304 174 286 180 274 Z" fill={dressCol.base} />
              <path d="M226 256 C248 268 258 296 262 316 L242 322 C235 304 226 286 220 274 Z" fill={dressCol.base} />
              <path d="M172 256 L228 256 L232 324 L168 324 Z" fill={dressCol.base} />
              <path d="M190 254 L200 288 L210 254 Z" fill="#FFFFFF" />
              <path d="M168 322 L232 322 L250 378 Q200 388 150 378 Z" fill={dressCol.shade} />
              <line x1="184" y1="324" x2="176" y2="380" stroke={LINE} strokeWidth="1.8" />
              <line x1="200" y1="324" x2="200" y2="382" stroke={LINE} strokeWidth="1.8" />
              <line x1="216" y1="324" x2="224" y2="380" stroke={LINE} strokeWidth="1.8" />
              <circle cx="200" cy="304" r="2.2" fill="#FBE8AC" strokeWidth="1.4" />
            </>
          )}

          {outfit.dress === 'cozyPajama' && (
            <>
              <path d="M172 254 C148 268 138 300 134 322 L156 328 C164 306 174 286 180 276 Z" fill={dressCol.base} />
              <path d="M228 254 C252 268 262 300 266 322 L244 328 C236 306 226 286 220 276 Z" fill={dressCol.base} />
              <path d="M170 254 Q200 248 230 254 L246 376 Q200 388 154 376 Z" fill={dressCol.base} />
              <path d="M182 254 Q200 268 218 254" fill="none" stroke={dressCol.highlight} strokeWidth="5" />
              <circle cx="186" cy="316" r="5" fill={dressAcc.base} stroke="none" opacity="0.65" />
              <circle cx="218" cy="340" r="5" fill={dressAcc.base} stroke="none" opacity="0.65" />
              <circle cx="176" cy="354" r="4" fill={dressAcc.base} stroke="none" opacity="0.65" />
            </>
          )}
        </g>
      )}

      {/* LAYER 10: NECKWEAR */}
      <g stroke={LINE} strokeWidth="2.2" strokeLinejoin="round">
        {outfit.neckwear === 'giantRibbon' && (
          <g>
            {/* Ribbon tails */}
            <path d="M196 268 L178 304 L192 298 L200 276 Z" fill={neckCol.base} />
            <path d="M204 268 L222 304 L208 298 L200 276 Z" fill={neckCol.base} />
            {/* Bow loops */}
            <path d="M196 266 C172 246 164 274 186 282 L198 272 Z" fill={neckCol.highlight} />
            <path d="M204 266 C228 246 236 274 214 282 L202 272 Z" fill={neckCol.highlight} />
            {/* Center gem brooch */}
            <circle cx="200" cy="268" r="7.5" fill="#E8E4EC" />
            <circle cx="198" cy="266" r="2.2" fill="#FFFFFF" stroke="none" />
          </g>
        )}

        {outfit.neckwear === 'pearlChoker' && (
          <g>
            <path d="M189 246 Q200 253 211 246" fill="none" stroke={neckCol.shade} strokeWidth="4" />
            <circle cx="192" cy="248" r="2.5" fill="#FFFFFF" strokeWidth="1.2" />
            <circle cx="200" cy="250" r="3.2" fill="#FFFFFF" strokeWidth="1.2" />
            <circle cx="208" cy="248" r="2.5" fill="#FFFFFF" strokeWidth="1.2" />
          </g>
        )}

        {outfit.neckwear === 'cozyScarf' && (
          <g>
            <path d="M206 254 L222 302 L204 304 L194 256 Z" fill={neckCol.shade} />
            <rect x="178" y="236" width="44" height="22" rx="10" fill={neckCol.base} />
            <line x1="186" y1="246" x2="214" y2="246" stroke={neckCol.highlight} strokeWidth="2.5" strokeLinecap="round" />
          </g>
        )}

        {outfit.neckwear === 'bellCollar' && (
          <g>
            <path d="M188 244 Q200 254 212 244" fill="none" stroke={neckCol.base} strokeWidth="5" strokeLinecap="round" />
            <circle cx="200" cy="255" r="5.5" fill="#FBE8AC" />
            <circle cx="200" cy="257" r="1.4" fill={LINE} stroke="none" />
          </g>
        )}
      </g>

      {/* LAYER 11: CHIBI HEAD & FACIAL FEATURES */}
      <g>
        {/* Ears */}
        <ellipse cx="124" cy="186" rx="9" ry="12" fill={skin.base} stroke={LINE} strokeWidth="2.4" />
        <ellipse cx="276" cy="186" rx="9" ry="12" fill={skin.base} stroke={LINE} strokeWidth="2.4" />

        {/* Chibi Head Base */}
        <path
          d="M124 176 C122 126 154 102 200 102 C246 102 278 126 276 176 C275 218 246 238 200 238 C154 238 125 218 124 176 Z"
          fill={skin.base}
          stroke={LINE}
          strokeWidth="2.6"
        />

        {/* Blush Layer */}
        {outfit.blushStyle === 'softOval' && (
          <>
            <ellipse cx="146" cy="212" rx="15" ry="8" fill={`url(#cheek-${uid})`} />
            <ellipse cx="254" cy="212" rx="15" ry="8" fill={`url(#cheek-${uid})`} />
          </>
        )}
        {outfit.blushStyle === 'peachDust' && (
          <>
            <ellipse cx="146" cy="212" rx="16" ry="9" fill="#F8A88D" opacity="0.38" />
            <ellipse cx="254" cy="212" rx="16" ry="9" fill="#F8A88D" opacity="0.38" />
            <line x1="141" y1="210" x2="144" y2="215" stroke="#EA8B78" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="147" y1="210" x2="150" y2="215" stroke="#EA8B78" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="250" y1="210" x2="253" y2="215" stroke="#EA8B78" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="256" y1="210" x2="259" y2="215" stroke="#EA8B78" strokeWidth="1.6" strokeLinecap="round" />
          </>
        )}
        {outfit.blushStyle === 'heartCheek' && (
          <>
            <ellipse cx="146" cy="212" rx="14" ry="7" fill={`url(#cheek-${uid})`} />
            <ellipse cx="254" cy="212" rx="14" ry="7" fill={`url(#cheek-${uid})`} />
            <path d="M146 211 C143 207 139 210 142 214 L146 218 L150 214 C153 210 149 207 146 211 Z" fill="#EB7B9D" />
            <path d="M254 211 C251 207 247 210 250 214 L254 218 L258 214 C261 210 257 207 254 211 Z" fill="#EB7B9D" />
          </>
        )}
        {outfit.blushStyle === 'freckles' && (
          <>
            <ellipse cx="146" cy="212" rx="13" ry="6" fill={`url(#cheek-${uid})`} />
            <ellipse cx="254" cy="212" rx="13" ry="6" fill={`url(#cheek-${uid})`} />
            <g fill="#B37D6A" opacity="0.65">
              <circle cx="142" cy="211" r="1.3" />
              <circle cx="148" cy="214" r="1.2" />
              <circle cx="152" cy="209" r="1.2" />
              <circle cx="248" cy="209" r="1.2" />
              <circle cx="252" cy="214" r="1.2" />
              <circle cx="258" cy="211" r="1.3" />
            </g>
          </>
        )}

        {/* Eyes */}
        {(() => {
          const renderOpenEye = (cx: number, isLeft: boolean, variant: 'jewel' | 'star' | 'sleepy' | 'cat' | 'heart') => {
            const ry = variant === 'sleepy' ? 16 : 20;
            const cy = variant === 'sleepy' ? 191 : 188;
            return (
              <g key={cx}>
                {/* Sclera */}
                <ellipse cx={cx} cy={cy} rx="19" ry={ry} fill="#FFFFFF" stroke={LINE} strokeWidth="2.2" />
                {/* Iris */}
                <ellipse cx={cx} cy={cy + 2} rx="14.5" ry={ry - 3.5} fill={`url(#iris-${uid})`} />
                {/* Pupil */}
                <ellipse cx={cx} cy={cy + 2} rx="6.5" ry="7.5" fill={eye.shade} opacity="0.88" />
                {/* Top lash shadow inside eye */}
                <path
                  d={`M${cx - 17} ${cy - 4} Q${cx} ${cy - 18} ${cx + 17} ${cy - 4}`}
                  fill="none"
                  stroke={eye.shade}
                  strokeWidth="3"
                  opacity="0.35"
                />
                {/* Thick kawaii upper eyelash */}
                <path
                  d={
                    variant === 'cat'
                      ? `M${cx - 21} ${cy - 2} Q${cx} ${cy - 23} ${cx + (isLeft ? 20 : 25)} ${cy - (isLeft ? 6 : 12)}`
                      : `M${cx - 21} ${cy - 3} Q${cx} ${cy - 24} ${cx + 21} ${cy - 3}`
                  }
                  fill="none"
                  stroke="#362430"
                  strokeWidth="5.2"
                  strokeLinecap="round"
                />
                {/* Lash wing tip */}
                <path
                  d={
                    isLeft
                      ? `M${cx - 19} ${cy - 4} L${cx - 25} ${cy - 10}`
                      : `M${cx + 19} ${cy - 4} L${cx + 25} ${cy - 10}`
                  }
                  stroke="#362430"
                  strokeWidth="3.6"
                  strokeLinecap="round"
                />
                {/* Main white sparkle */}
                <circle cx={cx - 6} cy={cy - 6} r="5.5" fill="#FFFFFF" />
                <circle cx={cx + 7} cy={cy + 7} r="2.6" fill="#FFFFFF" opacity="0.9" />
                {variant === 'star' && (
                  <path
                    d={`M${cx} ${cy - 3} L${cx + 2} ${cy + 2} L${cx + 7} ${cy + 4} L${cx + 2} ${cy + 6} L${cx} ${cy + 11} L${cx - 2} ${cy + 6} L${cx - 7} ${cy + 4} L${cx - 2} ${cy + 2} Z`}
                    fill="#FFFDF4"
                  />
                )}
                {variant === 'heart' && (
                  <path
                    d={`M${cx + 5} ${cy - 6} C${cx + 3} ${cy - 9} ${cx} ${cy - 6} ${cx + 2} ${cy - 3} L${cx + 5} ${cy} L${cx + 8} ${cy - 3} C${cx + 10} ${cy - 6} ${cx + 7} ${cy - 9} ${cx + 5} ${cy - 6} Z`}
                    fill="#FFFFFF"
                  />
                )}
              </g>
            );
          };

          if (outfit.eyeStyle === 'winkCharm') {
            return (
              <>
                {renderOpenEye(162, true, 'jewel')}
                <path d="M220 190 Q238 176 256 190" fill="none" stroke="#362430" strokeWidth="4.6" strokeLinecap="round" />
                <path d="M254 188 L261 182" stroke="#362430" strokeWidth="3.2" strokeLinecap="round" />
              </>
            );
          }

          const mapVariant: Record<Exclude<typeof outfit.eyeStyle, 'winkCharm'>, 'jewel' | 'star' | 'sleepy' | 'cat' | 'heart'> = {
            jewelRound: 'jewel',
            starrySparkle: 'star',
            sleepyDoe: 'sleepy',
            catEye: 'cat',
            heartShine: 'heart',
          };
          const v = mapVariant[outfit.eyeStyle];
          return (
            <>
              {renderOpenEye(162, true, v)}
              {renderOpenEye(238, false, v)}
            </>
          );
        })()}

        {/* Eyebrows */}
        <path d="M150 160 Q164 156 176 161" fill="none" stroke={LINE} strokeWidth="2.2" strokeLinecap="round" />
        <path d="M224 161 Q236 156 250 160" fill="none" stroke={LINE} strokeWidth="2.2" strokeLinecap="round" />

        {/* Nose whisper dot */}
        <circle cx="200" cy="204" r="1.2" fill={skin.shade} opacity="0.7" />

        {/* Mouth */}
        {outfit.mouthStyle === 'tinyDot' && (
          <path d="M196 218 Q200 220 204 218" fill="none" stroke={LINE} strokeWidth="2.3" strokeLinecap="round" />
        )}
        {outfit.mouthStyle === 'sweetSmile' && (
          <path d="M192 215 Q200 224 208 215" fill="none" stroke={LINE} strokeWidth="2.3" strokeLinecap="round" />
        )}
        {outfit.mouthStyle === 'kitty' && (
          <path d="M190 216 Q195 222 200 216 Q205 222 210 216" fill="none" stroke={LINE} strokeWidth="2.3" strokeLinecap="round" />
        )}
        {outfit.mouthStyle === 'happyOpen' && (
          <path d="M191 214 Q200 228 209 214 Z" fill="#E87A92" stroke={LINE} strokeWidth="2.1" strokeLinejoin="round" />
        )}
        {outfit.mouthStyle === 'shyPout' && (
          <path d="M195 220 Q200 215 205 220" fill="none" stroke={LINE} strokeWidth="2.3" strokeLinecap="round" />
        )}
        {outfit.mouthStyle === 'winkSmile' && (
          <path d="M193 218 Q202 222 209 213" fill="none" stroke={LINE} strokeWidth="2.3" strokeLinecap="round" />
        )}
      </g>

      {/* LAYER 12: EYEWEAR */}
      <g stroke={LINE} strokeWidth="2.2" fill="none">
        {outfit.eyewear === 'roundGlasses' && (
          <>
            <circle cx="162" cy="189" r="24" fill="#FFFFFF" fillOpacity="0.16" stroke="#7A655D" strokeWidth="2.5" />
            <circle cx="238" cy="189" r="24" fill="#FFFFFF" fillOpacity="0.16" stroke="#7A655D" strokeWidth="2.5" />
            <path d="M186 189 Q200 184 214 189" stroke="#7A655D" strokeWidth="2.5" />
          </>
        )}
        {outfit.eyewear === 'heartSunglasses' && (
          <>
            <path
              d="M162 178 C154 166 136 172 138 188 C140 202 156 212 162 216 C168 212 184 202 186 188 C188 172 170 166 162 178 Z"
              fill="#E87AA2"
              fillOpacity="0.58"
              stroke="#FFFFFF"
              strokeWidth="2.6"
            />
            <path
              d="M238 178 C230 166 212 172 214 188 C216 202 232 212 238 216 C244 212 260 202 262 188 C264 172 246 166 238 178 Z"
              fill="#E87AA2"
              fillOpacity="0.58"
              stroke="#FFFFFF"
              strokeWidth="2.6"
            />
            <line x1="186" y1="184" x2="214" y2="184" stroke="#FFFFFF" strokeWidth="2.6" />
          </>
        )}
        {outfit.eyewear === 'starMonocle' && (
          <>
            <circle cx="238" cy="189" r="24" fill="#FFF9E6" fillOpacity="0.16" stroke="#D1A64F" strokeWidth="2.6" />
            <path d="M262 194 Q274 216 266 244" stroke="#D1A64F" strokeWidth="1.8" strokeDasharray="3 3" />
            <circle cx="266" cy="246" r="3" fill="#FBE8AC" stroke="#D1A64F" strokeWidth="1.5" />
          </>
        )}
      </g>

      {/* LAYER 13: FRONT HAIR & BANGS */}
      <g stroke={LINE} strokeWidth="2.6" strokeLinejoin="round">
        {/* Shared lush crown silhouette + custom side locks & bangs */}
        {outfit.hairStyle === 'bobBuns' && (
          <>
            {/* Fluffy side locks */}
            <path d="M126 116 C108 148 104 206 122 242 C136 246 142 224 140 198 C138 172 142 152 148 142 Z" fill={`url(#hair-${uid})`} />
            <path d="M274 116 C292 148 296 206 278 242 C264 246 258 224 260 198 C262 172 258 152 252 142 Z" fill={`url(#hair-${uid})`} />
            {/* Crown & Blunt Wispy Bangs */}
            <path
              d="M122 162 C122 104 156 80 200 80 C244 80 278 104 278 162 L262 152 L252 168 L234 152 L222 168 L200 156 L178 168 L166 152 L148 168 L138 152 Z"
              fill={`url(#hair-${uid})`}
            />
          </>
        )}

        {outfit.hairStyle === 'himeLong' && (
          <>
            <path d="M124 126 C112 162 114 212 128 244 L144 236 L144 154 Z" fill={hair.base} />
            <path d="M276 126 C288 162 286 212 272 244 L256 236 L256 154 Z" fill={hair.base} />
            <path
              d="M122 158 C122 102 156 80 200 80 C244 80 278 102 278 158 L254 158 L244 166 L228 158 L200 164 L172 158 L156 166 L146 158 Z"
              fill={`url(#hair-${uid})`}
            />
          </>
        )}

        {outfit.hairStyle === 'twinTails' && (
          <>
            <path d="M124 128 C114 164 118 208 134 228 L146 196 L146 148 Z" fill={hair.base} />
            <path d="M276 128 C286 164 282 208 266 228 L254 196 L254 148 Z" fill={hair.base} />
            <path
              d="M122 156 C122 102 156 80 200 80 C244 80 278 102 278 156 L258 148 L242 168 L220 150 L200 172 L180 150 L158 168 L142 148 Z"
              fill={`url(#hair-${uid})`}
            />
          </>
        )}

        {outfit.hairStyle === 'fluffyPuff' && (
          <path
            d="M120 158 C120 100 156 78 200 78 C244 78 280 100 280 158 C264 150 250 168 236 156 C224 170 210 154 200 166 C190 154 176 170 164 156 C150 168 136 150 120 158 Z"
            fill={`url(#hair-${uid})`}
          />
        )}

        {outfit.hairStyle === 'sidePony' && (
          <path
            d="M122 160 C122 102 156 80 200 80 C244 80 278 102 278 160 L256 154 C240 166 218 148 192 168 L178 152 L154 170 L138 152 Z"
            fill={`url(#hair-${uid})`}
          />
        )}

        {outfit.hairStyle === 'wolfBob' && (
          <>
            <path d="M122 132 C108 176 112 224 132 248 L144 218 L146 156 Z" fill={hair.base} />
            <path d="M278 132 C292 176 288 224 268 248 L256 218 L254 156 Z" fill={hair.base} />
            <path
              d="M122 160 C122 102 156 80 200 80 C244 80 278 102 278 160 L258 146 L246 172 L224 150 L204 176 L186 152 L166 174 L148 148 Z"
              fill={`url(#hair-${uid})`}
            />
          </>
        )}

        {outfit.hairStyle === 'braidCrown' && (
          <>
            <path
              d="M122 156 C122 102 156 80 200 80 C244 80 278 102 278 156 Q244 146 212 162 L200 144 L188 162 Q156 146 122 156 Z"
              fill={`url(#hair-${uid})`}
            />
            {/* Braided headband arc */}
            <path d="M134 128 Q200 100 266 128" fill="none" stroke={hair.highlight} strokeWidth="9" strokeLinecap="round" />
            <path d="M134 128 Q200 100 266 128" fill="none" stroke={LINE} strokeWidth="2.2" strokeDasharray="10 8" />
          </>
        )}

        {outfit.hairStyle === 'curlyWaves' && (
          <>
            <path d="M124 126 C112 164 116 216 134 242 C146 232 146 184 146 152 Z" fill={hair.base} />
            <path d="M276 126 C288 164 284 216 266 242 C254 232 254 184 254 152 Z" fill={hair.base} />
            <path
              d="M122 158 C122 102 156 80 200 80 C244 80 278 102 278 158 C258 148 238 172 214 156 C202 164 196 150 184 164 C166 172 144 146 122 158 Z"
              fill={`url(#hair-${uid})`}
            />
          </>
        )}

        {/* Glossy kawaii hair shine halo */}
        <path
          d="M158 112 Q200 98 242 112"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="6"
          strokeLinecap="round"
          opacity="0.52"
        />
      </g>

      {/* LAYER 14: HEADWEAR */}
      <g stroke={LINE} strokeWidth="2.3" strokeLinejoin="round">
        {outfit.headwear === 'twinFlowerBows' && (
          <>
            {/* Left Ribbon Bow */}
            <g transform="translate(120 132) rotate(-18)">
              <path d="M-24 -12 L0 0 L-24 14 Q-30 2 -24 -12 Z" fill={headCol.base} />
              <path d="M24 -12 L0 0 L24 14 Q30 2 24 -12 Z" fill={headCol.base} />
              <path d="M-12 4 L-20 26 L-6 22 Z" fill={headCol.shade} />
              <path d="M12 4 L20 26 L6 22 Z" fill={headCol.shade} />
              <circle cx="0" cy="0" r="7" fill="#FFFFFF" />
              <circle cx="0" cy="0" r="2.6" fill="#FBE8AC" stroke="none" />
            </g>
            {/* Right Ribbon Bow */}
            <g transform="translate(280 132) rotate(18)">
              <path d="M-24 -12 L0 0 L-24 14 Q-30 2 -24 -12 Z" fill={headCol.base} />
              <path d="M24 -12 L0 0 L24 14 Q30 2 24 -12 Z" fill={headCol.base} />
              <path d="M-12 4 L-20 26 L-6 22 Z" fill={headCol.shade} />
              <path d="M12 4 L20 26 L6 22 Z" fill={headCol.shade} />
              <circle cx="0" cy="0" r="7" fill="#FFFFFF" />
              <circle cx="0" cy="0" r="2.6" fill="#FBE8AC" stroke="none" />
            </g>
          </>
        )}

        {outfit.headwear === 'fluffyBeret' && (
          <g transform="translate(216 86) rotate(10)">
            <ellipse cx="0" cy="0" rx="58" ry="26" fill={headCol.base} />
            <path d="M-4 -26 L2 -34" stroke={LINE} strokeWidth="3" strokeLinecap="round" />
            <ellipse cx="-16" cy="-8" rx="18" ry="6" fill={headCol.highlight} stroke="none" opacity="0.6" />
          </g>
        )}

        {outfit.headwear === 'catEars' && (
          <>
            <path d="M134 112 L144 64 L178 92 Z" fill={headCol.base} />
            <path d="M142 104 L148 76 L168 92 Z" fill="#F7C6D7" stroke="none" />
            <path d="M266 112 L256 64 L222 92 Z" fill={headCol.base} />
            <path d="M258 104 L252 76 L232 92 Z" fill="#F7C6D7" stroke="none" />
          </>
        )}

        {outfit.headwear === 'crownTiara' && (
          <g transform="translate(200 76)">
            <path d="M-32 14 L-36 -8 L-16 4 L0 -16 L16 4 L36 -8 L32 14 Z" fill={headCol.base} />
            <circle cx="0" cy="-16" r="4" fill="#FFFFFF" />
            <circle cx="-18" cy="2" r="3" fill="#F7C6D7" />
            <circle cx="18" cy="2" r="3" fill="#F7C6D7" />
          </g>
        )}

        {outfit.headwear === 'sailorCap' && (
          <g transform="translate(226 84) rotate(14)">
            <path d="M-34 8 C-34 -16 34 -16 34 8 Z" fill={headCol.highlight} />
            <rect x="-38" y="4" width="76" height="12" rx="6" fill={headCol.base} />
          </g>
        )}

        {outfit.headwear === 'bunnyEars' && (
          <>
            <path d="M150 96 C132 48 144 26 160 36 C172 44 174 74 170 94 Z" fill={headCol.highlight} />
            <path d="M153 88 C142 56 150 42 158 46 C164 50 165 72 162 88 Z" fill="#F7C6D7" stroke="none" />
            <path d="M250 96 C268 48 256 26 240 36 C228 44 226 74 230 94 Z" fill={headCol.highlight} />
            <path d="M247 88 C258 56 250 42 242 46 C236 50 235 72 238 88 Z" fill="#F7C6D7" stroke="none" />
          </>
        )}

        {outfit.headwear === 'pearlHeadband' && (
          <>
            <path d="M132 126 Q200 72 268 126" fill="none" stroke={headCol.base} strokeWidth="7" strokeLinecap="round" />
            {[154, 174, 200, 226, 246].map((x, idx) => {
              const y = idx === 2 ? 96 : idx === 1 || idx === 3 ? 102 : 112;
              return <circle key={x} cx={x} cy={y} r="4.5" fill="#FFFFFF" strokeWidth="1.6" />;
            })}
          </>
        )}

        {outfit.headwear === 'witchHat' && (
          <g transform="translate(200 84) rotate(-6)">
            <ellipse cx="0" cy="8" rx="64" ry="14" fill={headCol.base} />
            <path d="M-32 6 L-6 -56 L28 6 Z" fill={headCol.base} />
            <path d="M-26 2 L24 2" stroke="#FBE8AC" strokeWidth="5" />
            <circle cx="-4" cy="-32" r="4" fill="#FBE8AC" strokeWidth="1.5" />
          </g>
        )}
      </g>

      {/* LAYER 15: COMPANIONS & HANDHELD PROPS */}
      <g stroke={LINE} strokeWidth="2.2" strokeLinejoin="round">
        {outfit.companion === 'creamLamb' && (
          <g transform="translate(114 438)">
            {/* Fluffy wool body & ears */}
            <circle cx="0" cy="6" r="22" fill="#FFFDF7" />
            <circle cx="-18" cy="2" r="10" fill="#FFFDF7" />
            <circle cx="18" cy="2" r="10" fill="#FFFDF7" />
            <circle cx="-10" cy="-12" r="10" fill="#FFFDF7" />
            <circle cx="10" cy="-12" r="10" fill="#FFFDF7" />
            {/* Curled little horns */}
            <path d="M-16 -12 C-26 -18 -26 -2 -16 -2" fill="#F5DFAB" />
            <path d="M16 -12 C26 -18 26 -2 16 -2" fill="#F5DFAB" />
            {/* Face */}
            <ellipse cx="0" cy="6" rx="13" ry="11" fill="#FFF4DC" />
            <circle cx="-5" cy="5" r="1.7" fill={LINE} stroke="none" />
            <circle cx="5" cy="5" r="1.7" fill={LINE} stroke="none" />
            <path d="M-2 9 Q0 11 2 9" fill="none" stroke={LINE} strokeWidth="1.8" strokeLinecap="round" />
            <ellipse cx="-8" cy="8" rx="3" ry="1.8" fill="#F7B2C4" stroke="none" opacity="0.7" />
            <ellipse cx="8" cy="8" rx="3" ry="1.8" fill="#F7B2C4" stroke="none" opacity="0.7" />
          </g>
        )}

        {outfit.companion === 'bobaCup' && (
          <g transform="translate(274 328) rotate(8)">
            <path d="M-12 -18 L12 -18 L9 18 L-9 18 Z" fill="#F8D8E4" />
            <path d="M-10 4 L10 4 L9 18 L-9 18 Z" fill="#E8A2BE" stroke="none" />
            <ellipse cx="0" cy="-18" rx="13" ry="4" fill="#FFFFFF" />
            <rect x="2" y="-32" width="4" height="16" rx="1.5" fill="#C84B78" />
            <circle cx="-4" cy="12" r="2.2" fill="#4B3644" stroke="none" />
            <circle cx="2" cy="14" r="2.2" fill="#4B3644" stroke="none" />
            <circle cx="5" cy="9" r="2.2" fill="#4B3644" stroke="none" />
          </g>
        )}

        {outfit.companion === 'magicWand' && (
          <g transform="translate(272 316) rotate(22)">
            <rect x="-2.5" y="-12" width="5" height="62" rx="2.5" fill="#F7C6D7" />
            <path d="M0 -34 L6 -20 L20 -18 L9 -9 L12 5 L0 -2 L-12 5 L-9 -9 L-20 -18 L-6 -20 Z" fill="#FBE8AC" />
            <circle cx="0" cy="-14" r="5" fill="#C84B78" />
          </g>
        )}

        {outfit.companion === 'plushBear' && (
          <g transform="translate(116 436)">
            <circle cx="-13" cy="-14" r="8" fill="#DFBA98" />
            <circle cx="13" cy="-14" r="8" fill="#DFBA98" />
            <circle cx="0" cy="4" r="20" fill="#DFBA98" />
            <ellipse cx="0" cy="8" rx="9" ry="7" fill="#FAEBDD" stroke="none" />
            <circle cx="-6" cy="2" r="1.8" fill={LINE} stroke="none" />
            <circle cx="6" cy="2" r="1.8" fill={LINE} stroke="none" />
            <ellipse cx="0" cy="6" rx="3" ry="2" fill={LINE} stroke="none" />
            <path d="M-8 22 L0 18 L8 22 L0 26 Z" fill="#C84B78" />
          </g>
        )}

        {outfit.companion === 'ribbonTote' && (
          <g transform="translate(268 352)">
            <path d="M-10 -16 C-10 -32 10 -32 10 -16" fill="none" stroke={LINE} strokeWidth="2.6" />
            <rect x="-18" y="-16" width="36" height="32" rx="5" fill="#FBF6F8" />
            <line x1="-18" y1="-4" x2="18" y2="-4" stroke="#E8D8E0" strokeWidth="1.5" />
            <line x1="-18" y1="6" x2="18" y2="6" stroke="#E8D8E0" strokeWidth="1.5" />
            <circle cx="0" cy="-12" r="4" fill="#F7C6D7" />
          </g>
        )}

        {outfit.companion === 'starLantern' && (
          <g transform="translate(274 342)">
            <line x1="0" y1="-22" x2="0" y2="-6" stroke="#D1A64F" strokeWidth="2.4" />
            <rect x="-14" y="-6" width="28" height="34" rx="8" fill="#FFF7D6" stroke="#D1A64F" />
            <path d="M0 3 L3 10 L10 11 L5 16 L6 23 L0 19 L-6 23 L-5 16 L-10 11 L-3 10 Z" fill="#F6C85F" stroke="none" />
          </g>
        )}
      </g>
    </svg>
  );
};
