import React from 'react';
import {
  BACKDROP_ITEMS,
  BACK_ITEMS,
  BLUSH_STYLES,
  BOTTOM_ITEMS,
  CATEGORY_TABS,
  COMPANION_ITEMS,
  DRESS_ITEMS,
  EYE_COLORS,
  EYE_STYLES,
  EYEWEAR_ITEMS,
  GARMENT_COLORS,
  HAIR_COLORS,
  HAIR_STYLES,
  HEADWEAR_ITEMS,
  MOUTH_STYLES,
  NECKWEAR_ITEMS,
  SHOE_ITEMS,
  SKIN_TONES,
  SOCK_ITEMS,
  TOP_ITEMS,
} from '../data/wardrobeCatalog';
import {
  CategoryId,
  ChibiOutfit,
  ColorOption,
  SkinToneId,
  WardrobeItemMeta,
} from '../types/wardrobe';
import { ItemPreviewIcon } from './ItemPreviewIcon';

interface WardrobePanelProps {
  activeCategory: CategoryId;
  onSelectCategory: (category: CategoryId) => void;
  outfit: ChibiOutfit;
  onUpdateOutfit: (patch: Partial<ChibiOutfit>) => void;
  onSelectDress: (dressId: ChibiOutfit['dress']) => void;
  onSelectTop: (topId: ChibiOutfit['top']) => void;
  onSelectBottom: (bottomId: ChibiOutfit['bottom']) => void;
}

const ColorSwatches: React.FC<{
  label: string;
  colors: ColorOption[];
  selectedId: string;
  onSelect: (id: string) => void;
}> = ({ label, colors, selectedId, onSelect }) => {
  const activeColor = colors.find((c) => c.id === selectedId);
  return (
    <div className="mb-5 pb-4 border-b border-[#EDE6E2]">
      <div className="flex items-center justify-between mb-2.5">
        <span className="text-xs font-semibold text-[#6F5C66]">{label}</span>
        <span className="text-xs text-[#8E7B85]">{activeColor?.label ?? 'Custom'}</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {colors.map((swatch) => {
          const isSelected = swatch.id === selectedId;
          return (
            <button
              key={swatch.id}
              type="button"
              onClick={() => onSelect(swatch.id)}
              title={swatch.label}
              aria-label={`${label}: ${swatch.label}`}
              aria-pressed={isSelected}
              className={`w-8 h-8 rounded-lg border transition-transform duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C84B78] ${
                isSelected
                  ? 'border-[#C84B78] ring-2 ring-[#C84B78]/30 scale-105'
                  : 'border-[#DCD2CE] hover:scale-105'
              }`}
              style={{ backgroundColor: swatch.base }}
            />
          );
        })}
      </div>
    </div>
  );
};

interface ItemGridProps {
  items: WardrobeItemMeta[];
  kind: React.ComponentProps<typeof ItemPreviewIcon>['kind'];
  selectedId: string;
  outfit: ChibiOutfit;
  onSelect: (id: string) => void;
}

const ItemGrid: React.FC<ItemGridProps> = ({ items, kind, selectedId, outfit, onSelect }) => (
  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
    {items.map((item) => {
      const isSelected = item.id === selectedId;
      return (
        <button
          key={item.id}
          type="button"
          onClick={() => onSelect(item.id)}
          aria-pressed={isSelected}
          className={`group flex flex-col items-center justify-between p-3 rounded-xl border text-center transition-all duration-150 min-h-[108px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C84B78] ${
            isSelected
              ? 'bg-[#FDF4F7] border-[#C84B78] shadow-xs'
              : 'bg-white border-[#EAE2DE] hover:border-[#CFBFC6] hover:bg-[#FCF9FA]'
          }`}
        >
          <div className="flex items-center justify-center h-13 transition-transform duration-150 group-hover:scale-105">
            <ItemPreviewIcon kind={kind} itemId={item.id} outfit={outfit} />
          </div>
          <div className="w-full mt-1.5">
            <div
              className={`text-xs font-semibold truncate ${
                isSelected ? 'text-[#9F2E57]' : 'text-[#2D2129]'
              }`}
            >
              {item.name}
            </div>
            <div className="text-[11px] text-[#8E7B85] truncate">{item.styleTag}</div>
          </div>
        </button>
      );
    })}
  </div>
);

export const WardrobePanel: React.FC<WardrobePanelProps> = ({
  activeCategory,
  onSelectCategory,
  outfit,
  onUpdateOutfit,
  onSelectDress,
  onSelectTop,
  onSelectBottom,
}) => {
  const skinOptions = Object.values(SKIN_TONES);

  return (
    <section
      aria-label="Wardrobe Customizer"
      className="bg-white border border-[#EAE2DE] rounded-2xl flex flex-col h-full overflow-hidden"
    >
      {/* Category Navigation Strip */}
      <div className="border-b border-[#EAE2DE] px-3 py-2.5 bg-[#FCFAF8]">
        <div
          role="tablist"
          aria-label="Wardrobe categories"
          className="flex items-center gap-1.5 overflow-x-auto wardrobe-scroll pb-1"
        >
          {CATEGORY_TABS.map((tab) => {
            const active = tab.id === activeCategory;
            return (
              <button
                key={tab.id}
                role="tab"
                type="button"
                aria-selected={active}
                onClick={() => onSelectCategory(tab.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C84B78] ${
                  active
                    ? 'bg-[#C84B78] text-white'
                    : 'text-[#62505A] hover:text-[#2D2129] hover:bg-[#F3ECE9]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Category Content Body */}
      <div className="p-5 overflow-y-auto wardrobe-scroll flex-1 max-h-[600px] lg:max-h-[640px]">
        {activeCategory === 'face' && (
          <div className="space-y-6">
            <ColorSwatches
              label="Skin Tone"
              colors={skinOptions}
              selectedId={outfit.skinTone}
              onSelect={(id) => onUpdateOutfit({ skinTone: id as SkinToneId })}
            />
            <ColorSwatches
              label="Iris Color"
              colors={EYE_COLORS}
              selectedId={outfit.eyeColor}
              onSelect={(id) => onUpdateOutfit({ eyeColor: id })}
            />
            <div>
              <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Eye Expression</h3>
              <ItemGrid
                items={EYE_STYLES}
                kind="eye"
                selectedId={outfit.eyeStyle}
                outfit={outfit}
                onSelect={(id) => onUpdateOutfit({ eyeStyle: id as ChibiOutfit['eyeStyle'] })}
              />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Mouth</h3>
              <ItemGrid
                items={MOUTH_STYLES}
                kind="mouth"
                selectedId={outfit.mouthStyle}
                outfit={outfit}
                onSelect={(id) => onUpdateOutfit({ mouthStyle: id as ChibiOutfit['mouthStyle'] })}
              />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Cheek & Blush</h3>
              <ItemGrid
                items={BLUSH_STYLES}
                kind="blush"
                selectedId={outfit.blushStyle}
                outfit={outfit}
                onSelect={(id) => onUpdateOutfit({ blushStyle: id as ChibiOutfit['blushStyle'] })}
              />
            </div>
          </div>
        )}

        {activeCategory === 'hair' && (
          <div>
            <ColorSwatches
              label="Hair Color"
              colors={HAIR_COLORS}
              selectedId={outfit.hairColor}
              onSelect={(id) => onUpdateOutfit({ hairColor: id })}
            />
            <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Hairstyles</h3>
            <ItemGrid
              items={HAIR_STYLES}
              kind="hair"
              selectedId={outfit.hairStyle}
              outfit={outfit}
              onSelect={(id) => onUpdateOutfit({ hairStyle: id as ChibiOutfit['hairStyle'] })}
            />
          </div>
        )}

        {activeCategory === 'dresses' && (
          <div>
            <ColorSwatches
              label="Dress Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.dressColor}
              onSelect={(id) => onUpdateOutfit({ dressColor: id })}
            />
            <ColorSwatches
              label="Trim & Accent Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.dressAccent}
              onSelect={(id) => onUpdateOutfit({ dressAccent: id })}
            />
            <div className="flex items-baseline justify-between mb-3">
              <h3 className="text-sm font-semibold text-[#2D2129]">Full Dresses & Sets</h3>
              <span className="text-xs text-[#8E7B85]">Replaces top & bottom</span>
            </div>
            <ItemGrid
              items={DRESS_ITEMS}
              kind="dress"
              selectedId={outfit.dress}
              outfit={outfit}
              onSelect={(id) => onSelectDress(id as ChibiOutfit['dress'])}
            />
          </div>
        )}

        {activeCategory === 'tops' && (
          <div>
            <ColorSwatches
              label="Top Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.topColor}
              onSelect={(id) => onUpdateOutfit({ topColor: id })}
            />
            <div className="flex items-baseline justify-between mb-3">
              <h3 className="text-sm font-semibold text-[#2D2129]">Blouses & Knitwear</h3>
              {outfit.dress !== 'none' && (
                <span className="text-xs text-[#9F2E57]">Auto-switches from dress</span>
              )}
            </div>
            <ItemGrid
              items={TOP_ITEMS}
              kind="top"
              selectedId={outfit.top}
              outfit={outfit}
              onSelect={(id) => onSelectTop(id as ChibiOutfit['top'])}
            />
          </div>
        )}

        {activeCategory === 'bottoms' && (
          <div>
            <ColorSwatches
              label="Skirt & Shorts Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.bottomColor}
              onSelect={(id) => onUpdateOutfit({ bottomColor: id })}
            />
            <div className="flex items-baseline justify-between mb-3">
              <h3 className="text-sm font-semibold text-[#2D2129]">Skirts, Shorts & Trousers</h3>
              {outfit.dress !== 'none' && (
                <span className="text-xs text-[#9F2E57]">Auto-switches from dress</span>
              )}
            </div>
            <ItemGrid
              items={BOTTOM_ITEMS}
              kind="bottom"
              selectedId={outfit.bottom}
              outfit={outfit}
              onSelect={(id) => onSelectBottom(id as ChibiOutfit['bottom'])}
            />
          </div>
        )}

        {activeCategory === 'socks' && (
          <div>
            <ColorSwatches
              label="Socks & Tights Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.socksColor}
              onSelect={(id) => onUpdateOutfit({ socksColor: id })}
            />
            <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Hosiery & Legwear</h3>
            <ItemGrid
              items={SOCK_ITEMS}
              kind="sock"
              selectedId={outfit.socks}
              outfit={outfit}
              onSelect={(id) => onUpdateOutfit({ socks: id as ChibiOutfit['socks'] })}
            />
          </div>
        )}

        {activeCategory === 'shoes' && (
          <div>
            <ColorSwatches
              label="Footwear Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.shoesColor}
              onSelect={(id) => onUpdateOutfit({ shoesColor: id })}
            />
            <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Shoes & Slippers</h3>
            <ItemGrid
              items={SHOE_ITEMS}
              kind="shoe"
              selectedId={outfit.shoes}
              outfit={outfit}
              onSelect={(id) => onUpdateOutfit({ shoes: id as ChibiOutfit['shoes'] })}
            />
          </div>
        )}

        {activeCategory === 'headwear' && (
          <div>
            <ColorSwatches
              label="Headwear Color"
              colors={GARMENT_COLORS}
              selectedId={outfit.headwearColor}
              onSelect={(id) => onUpdateOutfit({ headwearColor: id })}
            />
            <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Bows, Berets & Ears</h3>
            <ItemGrid
              items={HEADWEAR_ITEMS}
              kind="headwear"
              selectedId={outfit.headwear}
              outfit={outfit}
              onSelect={(id) => onUpdateOutfit({ headwear: id as ChibiOutfit['headwear'] })}
            />
          </div>
        )}

        {activeCategory === 'accessories' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Eyewear</h3>
              <ItemGrid
                items={EYEWEAR_ITEMS}
                kind="eyewear"
                selectedId={outfit.eyewear}
                outfit={outfit}
                onSelect={(id) => onUpdateOutfit({ eyewear: id as ChibiOutfit['eyewear'] })}
              />
            </div>

            <div className="pt-4 border-t border-[#EDE6E2]">
              <ColorSwatches
                label="Neckwear Color"
                colors={GARMENT_COLORS}
                selectedId={outfit.neckwearColor}
                onSelect={(id) => onUpdateOutfit({ neckwearColor: id })}
              />
              <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Ribbons, Chokers & Scarves</h3>
              <ItemGrid
                items={NECKWEAR_ITEMS}
                kind="neckwear"
                selectedId={outfit.neckwear}
                outfit={outfit}
                onSelect={(id) => onUpdateOutfit({ neckwear: id as ChibiOutfit['neckwear'] })}
              />
            </div>

            <div className="pt-4 border-t border-[#EDE6E2]">
              <ColorSwatches
                label="Wings & Sash Color"
                colors={GARMENT_COLORS}
                selectedId={outfit.backItemColor}
                onSelect={(id) => onUpdateOutfit({ backItemColor: id })}
              />
              <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Wings & Back Sashes</h3>
              <ItemGrid
                items={BACK_ITEMS}
                kind="backItem"
                selectedId={outfit.backItem}
                outfit={outfit}
                onSelect={(id) => onUpdateOutfit({ backItem: id as ChibiOutfit['backItem'] })}
              />
            </div>
          </div>
        )}

        {activeCategory === 'companions' && (
          <div>
            <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Plushies & Handheld Props</h3>
            <ItemGrid
              items={COMPANION_ITEMS}
              kind="companion"
              selectedId={outfit.companion}
              outfit={outfit}
              onSelect={(id) => onUpdateOutfit({ companion: id as ChibiOutfit['companion'] })}
            />
          </div>
        )}

        {activeCategory === 'backdrops' && (
          <div>
            <h3 className="text-sm font-semibold text-[#2D2129] mb-3">Studio Backdrops</h3>
            <ItemGrid
              items={BACKDROP_ITEMS}
              kind="backdrop"
              selectedId={outfit.backdrop}
              outfit={outfit}
              onSelect={(id) => onUpdateOutfit({ backdrop: id as ChibiOutfit['backdrop'] })}
            />
          </div>
        )}
      </div>
    </section>
  );
};
