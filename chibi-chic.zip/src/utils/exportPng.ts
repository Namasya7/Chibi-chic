export async function exportSvgToPng(
  svgElement: SVGSVGElement | null,
  fileName: string
): Promise<boolean> {
  if (!svgElement) return false;

  const serializer = new XMLSerializer();
  const clone = svgElement.cloneNode(true) as SVGSVGElement;
  clone.setAttribute('width', '1200');
  clone.setAttribute('height', '1560');

  const svgStr = serializer.serializeToString(clone);
  const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = 1560;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        URL.revokeObjectURL(url);
        resolve(false);
        return;
      }
      ctx.fillStyle = '#FAF8F6';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      canvas.toBlob((pngBlob) => {
        URL.revokeObjectURL(url);
        if (!pngBlob) {
          resolve(false);
          return;
        }
        const dlUrl = URL.createObjectURL(pngBlob);
        const link = document.createElement('a');
        link.href = dlUrl;
        const safeName = fileName
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)/g, '');
        link.download = `chibi-chic-${safeName || 'look'}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(dlUrl), 1000);
        resolve(true);
      }, 'image/png');
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(false);
    };
    img.src = url;
  });
}
