import {
  BackdropId,
  BackItemId,
  BlushStyleId,
  BottomId,
  CategoryId,
  ChibiOutfit,
  ColorOption,
  CompanionId,
  DressId,
  EyeStyleId,
  EyewearId,
  HairStyleId,
  HeadwearId,
  MouthStyleId,
  NeckwearId,
  SavedLook,
  ShoeId,
  SkinToneId,
  SockId,
  StyleChallengePrompt,
  TopId,
  WardrobeItemMeta,
} from '../types/wardrobe';

export const CATEGORY_TABS: { id: CategoryId; label: string }[] = [
  { id: 'face', label: 'Face' },
  { id: 'hair', label: 'Hair' },
  { id: 'dresses', label: 'Dresses' },
  { id: 'tops', label: 'Tops' },
  { id: 'bottoms', label: 'Bottoms' },
  { id: 'socks', label: 'Socks' },
  { id: 'shoes', label: 'Shoes' },
  { id: 'headwear', label: 'Headwear' },
  { id: 'accessories', label: 'Extras' },
  { id: 'companions', label: 'Props' },
  { id: 'backdrops', label: 'Scenes' },
];

export const SKIN_TONES: Record<SkinToneId, ColorOption> = {
  porcelain: { id: 'porcelain', label: 'Porcelain', base: '#FFF2ED', shade: '#F3D6CC', highlight: '#FFF9F7' },
  peach: { id: 'peach', label: 'Soft Peach', base: '#FFE6D9', shade: '#EFC2AF', highlight: '#FFF4EE' },
  warmIvory: { id: 'warmIvory', label: 'Warm Ivory', base: '#F8D7BF', shade: '#DFB092', highlight: '#FDE8D8' },
  honey: { id: 'honey', label: 'Golden Honey', base: '#E8B892', shade: '#CA936B', highlight: '#F4CEAE' },
  caramel: { id: 'caramel', label: 'Caramel', base: '#C78A62', shade: '#A36643', highlight: '#D99F78' },
  espresso: { id: 'espresso', label: 'Espresso', base: '#8B5840', shade: '#683D2A', highlight: '#A16E55' },
};

export const HAIR_COLORS: ColorOption[] = [
  { id: 'silverLilac', label: 'Silver Lilac', base: '#ECE7F2', shade: '#C9C0D6', highlight: '#FAF8FC' },
  { id: 'sakuraPink', label: 'Sakura Pink', base: '#F7C4D3', shade: '#D996AC', highlight: '#FCE2EA' },
  { id: 'honeyBlonde', label: 'Honey Blonde', base: '#F4D896', shade: '#D4AF63', highlight: '#FBF0CC' },
  { id: 'cocoaBrown', label: 'Cocoa Brown', base: '#7E5A52', shade: '#5A3C36', highlight: '#9B756D' },
  { id: 'midnightInk', label: 'Midnight Ink', base: '#3B3442', shade: '#231E29', highlight: '#5B5164' },
  { id: 'mintCream', label: 'Mint Cream', base: '#BEE6D8', shade: '#8FC2B0', highlight: '#DCF5EC' },
  { id: 'lavenderDream', label: 'Lavender', base: '#CBB8EA', shade: '#9F88C8', highlight: '#E5DAFA' },
  { id: 'peachSorbet', label: 'Peach Sorbet', base: '#F6BFA8', shade: '#D69177', highlight: '#FCE0D3' },
  { id: 'berryCrimson', label: 'Berry Rose', base: '#B5486B', shade: '#872D4B', highlight: '#D46E8F' },
  { id: 'ashSlate', label: 'Ash Mist', base: '#A9A8B5', shade: '#807E8E', highlight: '#CECDD9' },
];

export const EYE_COLORS: ColorOption[] = [
  { id: 'roseQuartz', label: 'Rose Quartz', base: '#D48DA6', shade: '#8E4964', highlight: '#F6CEDC' },
  { id: 'lavender', label: 'Violet Dew', base: '#A48BD1', shade: '#614891', highlight: '#D7C9F2' },
  { id: 'skyAzure', label: 'Sky Azure', base: '#7CB3E0', shade: '#3B6F9C', highlight: '#C2E2FA' },
  { id: 'emeraldMint', label: 'Emerald Mint', base: '#6FBFA3', shade: '#357D65', highlight: '#BCECE0' },
  { id: 'honeyAmber', label: 'Honey Amber', base: '#D99E52', shade: '#915C22', highlight: '#F7D59C' },
  { id: 'berryRuby', label: 'Berry Ruby', base: '#C44D6E', shade: '#7D223C', highlight: '#F29EB5' },
  { id: 'midnight', label: 'Deep Indigo', base: '#4C5278', shade: '#282C47', highlight: '#9399BF' },
  { id: 'warmCocoa', label: 'Warm Cocoa', base: '#7B574A', shade: '#4A3026', highlight: '#B58E7F' },
];

export const GARMENT_COLORS: ColorOption[] = [
  { id: 'cloudWhite', label: 'Cloud White', base: '#FBF9FC', shade: '#DFD6E4', highlight: '#FFFFFF' },
  { id: 'blushPink', label: 'Blush Pink', base: '#F7C6D7', shade: '#D994AD', highlight: '#FDE5EE' },
  { id: 'butterCream', label: 'Butter Cream', base: '#FBE8AC', shade: '#DEC173', highlight: '#FEF4D4' },
  { id: 'lavenderMist', label: 'Lavender Mist', base: '#D8CCF2', shade: '#AE9CD4', highlight: '#ECE6FA' },
  { id: 'powderBlue', label: 'Powder Blue', base: '#BFE0F7', shade: '#8BB8D9', highlight: '#E0F1FC' },
  { id: 'sageMint', label: 'Sage Mint', base: '#C2E6D3', shade: '#8DC2A7', highlight: '#E1F5EA' },
  { id: 'berryRose', label: 'Berry Rose', base: '#C84B78', shade: '#942C52', highlight: '#E3789E' },
  { id: 'velvetNoir', label: 'Velvet Noir', base: '#3D3542', shade: '#241E29', highlight: '#5E5366' },
  { id: 'navyInk', label: 'Academy Navy', base: '#3C4A6B', shade: '#25304A', highlight: '#607199' },
  { id: 'terracottaPeach', label: 'Apricot', base: '#F4B69C', shade: '#D1876A', highlight: '#FAD9CB' },
];

export function resolveColor(list: ColorOption[], id: string, fallbackIdx = 0): ColorOption {
  return list.find((c) => c.id === id) ?? list[fallbackIdx];
}

export const EYE_STYLES: WardrobeItemMeta<EyeStyleId>[] = [
  { id: 'jewelRound', name: 'Jewel Round', styleTag: 'Classic', tags: ['pastel', 'sweet', 'classic'] },
  { id: 'starrySparkle', name: 'Starry Sparkle', styleTag: 'Idol', tags: ['starlight', 'idol', 'party'] },
  { id: 'winkCharm', name: 'Playful Wink', styleTag: 'Cheerful', tags: ['pop', 'idol', 'cheerful'] },
  { id: 'sleepyDoe', name: 'Sleepy Doe', styleTag: 'Cozy', tags: ['cozy', 'dreamy', 'soft'] },
  { id: 'catEye', name: 'Velvet Cat', styleTag: 'Chic', tags: ['chic', 'gothic', 'cool'] },
  { id: 'heartShine', name: 'Heart Shine', styleTag: 'Sweet', tags: ['sweet', 'tea', 'pastel'] },
];

export const MOUTH_STYLES: WardrobeItemMeta<MouthStyleId>[] = [
  { id: 'tinyDot', name: 'Dainty Dot', styleTag: 'Poised', tags: ['classic', 'pastel'] },
  { id: 'sweetSmile', name: 'Sweet Smile', styleTag: 'Warm', tags: ['sweet', 'tea', 'cheerful'] },
  { id: 'kitty', name: 'Kitty :3', styleTag: 'Playful', tags: ['cozy', 'pop', 'kitty'] },
  { id: 'happyOpen', name: 'Sunny Grin', styleTag: 'Joyful', tags: ['idol', 'cheerful'] },
  { id: 'shyPout', name: 'Shy Pout', styleTag: 'Coy', tags: ['soft', 'pastel'] },
  { id: 'winkSmile', name: 'Smirk Smile', styleTag: 'Chic', tags: ['chic', 'cool'] },
];

export const BLUSH_STYLES: WardrobeItemMeta<BlushStyleId>[] = [
  { id: 'softOval', name: 'Soft Oval', styleTag: 'Classic', tags: ['pastel', 'sweet'] },
  { id: 'peachDust', name: 'Peach Glow', styleTag: 'Warm', tags: ['cozy', 'warm'] },
  { id: 'heartCheek', name: 'Heart Cheek', styleTag: 'Idol', tags: ['idol', 'pop'] },
  { id: 'freckles', name: 'Sun Freckles', styleTag: 'Natural', tags: ['cozy', 'casual'] },
  { id: 'none', name: 'Clean Cheek', styleTag: 'Minimal', tags: ['minimal'] },
];

export const HAIR_STYLES: WardrobeItemMeta<HairStyleId>[] = [
  { id: 'bobBuns', name: 'Fluffy Bob & Buns', styleTag: 'Signature', tags: ['pastel', 'sweet', 'tea', 'classic'] },
  { id: 'himeLong', name: 'Silky Hime Cut', styleTag: 'Elegant', tags: ['tea', 'starlight', 'classic'] },
  { id: 'twinTails', name: 'Ribbon Twin Tails', styleTag: 'Idol', tags: ['idol', 'pop', 'pastel'] },
  { id: 'fluffyPuff', name: 'Cloud Puffs', styleTag: 'Cozy', tags: ['cozy', 'sweet', 'soft'] },
  { id: 'sidePony', name: 'Side Ponytail', styleTag: 'Casual', tags: ['casual', 'academy', 'cheerful'] },
  { id: 'wolfBob', name: 'Layered Wolf Bob', styleTag: 'Street', tags: ['chic', 'cool', 'street'] },
  { id: 'braidCrown', name: 'Braided Crown', styleTag: 'Fairytale', tags: ['starlight', 'tea', 'fairytale'] },
  { id: 'curlyWaves', name: 'Dreamy Waves', styleTag: 'Romantic', tags: ['tea', 'starlight', 'pastel'] },
];

export const DRESS_ITEMS: WardrobeItemMeta<DressId>[] = [
  { id: 'none', name: 'No Dress', styleTag: 'Separates', tags: [] },
  { id: 'capeletBow', name: 'Capelet Bow Dress', styleTag: 'Boutique', tags: ['pastel', 'tea', 'sweet', 'classic'] },
  { id: 'strawberryLolita', name: 'Berry Tiered Dress', styleTag: 'Sweet', tags: ['tea', 'pastel', 'sweet'] },
  { id: 'maidFrill', name: 'Frill Apron Dress', styleTag: 'Cafe', tags: ['tea', 'cafe', 'classic'] },
  { id: 'starlightGown', name: 'Starlight Ballgown', styleTag: 'Evening', tags: ['starlight', 'party', 'fairytale'] },
  { id: 'academySet', name: 'Pleated Blazer Dress', styleTag: 'Academy', tags: ['academy', 'chic', 'preppy'] },
  { id: 'cozyPajama', name: 'Cloud Nightie', styleTag: 'Cozy', tags: ['cozy', 'sleepwear', 'soft'] },
];

export const TOP_ITEMS: WardrobeItemMeta<TopId>[] = [
  { id: 'none', name: 'No Top', styleTag: 'Base', tags: [] },
  { id: 'peterPanBlouse', name: 'Peter Pan Blouse', styleTag: 'Classic', tags: ['tea', 'academy', 'classic'] },
  { id: 'knitCardigan', name: 'Button Cardigan', styleTag: 'Cozy', tags: ['cozy', 'academy', 'soft'] },
  { id: 'sailorTop', name: 'Sailor Collar Top', styleTag: 'Preppy', tags: ['academy', 'idol', 'pop'] },
  { id: 'offShoulderFrill', name: 'Off-Shoulder Frill', styleTag: 'Romantic', tags: ['pastel', 'idol', 'party'] },
  { id: 'oversizedHoodie', name: 'Cloud Hoodie', styleTag: 'Street', tags: ['cozy', 'casual', 'street'] },
  { id: 'sweetheartTee', name: 'Sweetheart Knit Tee', styleTag: 'Casual', tags: ['casual', 'pop', 'sweet'] },
];

export const BOTTOM_ITEMS: WardrobeItemMeta<BottomId>[] = [
  { id: 'none', name: 'No Bottom', styleTag: 'Base', tags: [] },
  { id: 'pleatedSkirt', name: 'Pleated Mini Skirt', styleTag: 'Academy', tags: ['academy', 'idol', 'classic'] },
  { id: 'tieredRuffle', name: 'Tiered Ruffle Skirt', styleTag: 'Sweet', tags: ['pastel', 'tea', 'sweet'] },
  { id: 'denimShorts', name: 'Cuffed Shorts', styleTag: 'Casual', tags: ['casual', 'street', 'pop'] },
  { id: 'cozyBloomers', name: 'Lace Bloomers', styleTag: 'Cozy', tags: ['cozy', 'tea', 'soft'] },
  { id: 'highTrousers', name: 'Tailored Culottes', styleTag: 'Chic', tags: ['chic', 'academy'] },
  { id: 'pinaforeSkirt', name: 'Button Suspender Skirt', styleTag: 'Boutique', tags: ['tea', 'academy', 'pastel'] },
];

export const SOCK_ITEMS: WardrobeItemMeta<SockId>[] = [
  { id: 'none', name: 'Bare Leg', styleTag: 'None', tags: [] },
  { id: 'ankleFrill', name: 'Ankle Lace Socks', styleTag: 'Dainty', tags: ['tea', 'pastel', 'sweet'] },
  { id: 'kneeRibbon', name: 'Ribbon Knee-Highs', styleTag: 'Signature', tags: ['pastel', 'academy', 'classic'] },
  { id: 'stripedOverKnee', name: 'Striped Over-Knee', styleTag: 'Pop', tags: ['idol', 'pop', 'street'] },
  { id: 'laceTights', name: 'Sheer Dot Tights', styleTag: 'Evening', tags: ['starlight', 'chic', 'tea'] },
  { id: 'fluffyWarmers', name: 'Fluffy Leg Warmers', styleTag: 'Cozy', tags: ['cozy', 'street', 'soft'] },
];

export const SHOE_ITEMS: WardrobeItemMeta<ShoeId>[] = [
  { id: 'none', name: 'Barefoot', styleTag: 'None', tags: [] },
  { id: 'bowMaryJanes', name: 'Ribbon Mary Janes', styleTag: 'Boutique', tags: ['pastel', 'tea', 'classic'] },
  { id: 'platformLoafers', name: 'Platform Loafers', styleTag: 'Academy', tags: ['academy', 'chic'] },
  { id: 'ribbonBallet', name: 'Ballet Pointe Flats', styleTag: 'Grace', tags: ['starlight', 'pastel', 'tea'] },
  { id: 'laceBoots', name: 'Lace-Up Boots', styleTag: 'Street', tags: ['street', 'chic', 'cozy'] },
  { id: 'bunnySlippers', name: 'Fluffy Bunny Slippers', styleTag: 'Cozy', tags: ['cozy', 'soft'] },
  { id: 'starSneakers', name: 'Star High-Tops', styleTag: 'Pop', tags: ['idol', 'pop', 'casual'] },
];

export const HEADWEAR_ITEMS: WardrobeItemMeta<HeadwearId>[] = [
  { id: 'none', name: 'No Headwear', styleTag: 'Clean', tags: [] },
  { id: 'twinFlowerBows', name: 'Twin Blossom Bows', styleTag: 'Signature', tags: ['pastel', 'tea', 'sweet'] },
  { id: 'fluffyBeret', name: 'Woolen Beret', styleTag: 'Atelier', tags: ['academy', 'chic', 'cozy'] },
  { id: 'catEars', name: 'Plush Cat Ears', styleTag: 'Playful', tags: ['idol', 'pop', 'cozy'] },
  { id: 'crownTiara', name: 'Pearl Tiara', styleTag: 'Royal', tags: ['starlight', 'party', 'fairytale'] },
  { id: 'sailorCap', name: 'Mini Sailor Cap', styleTag: 'Preppy', tags: ['academy', 'pop'] },
  { id: 'bunnyEars', name: 'Lop Bunny Ears', styleTag: 'Sweet', tags: ['pastel', 'sweet', 'cozy'] },
  { id: 'pearlHeadband', name: 'Pearl Halo Band', styleTag: 'Elegant', tags: ['tea', 'starlight', 'classic'] },
  { id: 'witchHat', name: 'Starry Mini Hat', styleTag: 'Whimsy', tags: ['starlight', 'party'] },
];

export const EYEWEAR_ITEMS: WardrobeItemMeta<EyewearId>[] = [
  { id: 'none', name: 'No Glasses', styleTag: 'Clear', tags: [] },
  { id: 'roundGlasses', name: 'Wire Round Glasses', styleTag: 'Scholar', tags: ['academy', 'cozy', 'chic'] },
  { id: 'heartSunglasses', name: 'Heart Tint Shades', styleTag: 'Pop', tags: ['idol', 'pop', 'party'] },
  { id: 'starMonocle', name: 'Starry Chain Rim', styleTag: 'Whimsy', tags: ['starlight', 'tea'] },
];

export const NECKWEAR_ITEMS: WardrobeItemMeta<NeckwearId>[] = [
  { id: 'none', name: 'No Neckwear', styleTag: 'Clean', tags: [] },
  { id: 'giantRibbon', name: 'Gem Ribbon Bow', styleTag: 'Boutique', tags: ['pastel', 'tea', 'classic'] },
  { id: 'pearlChoker', name: 'Velvet Pearl Choker', styleTag: 'Evening', tags: ['starlight', 'chic', 'tea'] },
  { id: 'cozyScarf', name: 'Knit Neck Scarf', styleTag: 'Cozy', tags: ['cozy', 'winter'] },
  { id: 'bellCollar', name: 'Gold Bell Ribbon', styleTag: 'Playful', tags: ['idol', 'pop', 'sweet'] },
];

export const BACK_ITEMS: WardrobeItemMeta<BackItemId>[] = [
  { id: 'none', name: 'No Back Piece', styleTag: 'Clean', tags: [] },
  { id: 'angelWings', name: 'Feathered Angel Wings', styleTag: 'Celestial', tags: ['starlight', 'pastel', 'fairytale'] },
  { id: 'batWings', name: 'Velvet Bat Wings', styleTag: 'Night', tags: ['starlight', 'chic', 'party'] },
  { id: 'fairyWings', name: 'Iridescent Fairy Wings', styleTag: 'Dreamy', tags: ['pastel', 'fairytale', 'tea'] },
  { id: 'ribbonCape', name: 'Back Sash Bow', styleTag: 'Boutique', tags: ['tea', 'idol', 'sweet'] },
];

export const COMPANION_ITEMS: WardrobeItemMeta<CompanionId>[] = [
  { id: 'none', name: 'No Companion', styleTag: 'Solo', tags: [] },
  { id: 'creamLamb', name: 'Cream Lamb Plush', styleTag: 'Signature', tags: ['pastel', 'cozy', 'sweet', 'tea'] },
  { id: 'bobaCup', name: 'Berry Boba Tea', styleTag: 'Cafe', tags: ['casual', 'pop', 'cozy'] },
  { id: 'magicWand', name: 'Starlight Wand', styleTag: 'Magical', tags: ['starlight', 'idol', 'fairytale'] },
  { id: 'plushBear', name: 'Honey Teddy Bear', styleTag: 'Cozy', tags: ['cozy', 'sweet', 'soft'] },
  { id: 'ribbonTote', name: 'Quilted Ribbon Tote', styleTag: 'Atelier', tags: ['academy', 'chic', 'tea'] },
  { id: 'starLantern', name: 'Moonlight Lantern', styleTag: 'Evening', tags: ['starlight', 'fairytale'] },
];

export const BACKDROP_ITEMS: WardrobeItemMeta<BackdropId>[] = [
  { id: 'atelierCream', name: 'Atelier Ivory', styleTag: 'Studio', tags: ['classic', 'pastel', 'chic'] },
  { id: 'sakuraGarden', name: 'Sakura Terrace', styleTag: 'Spring', tags: ['tea', 'pastel', 'sweet'] },
  { id: 'starryNight', name: 'Starry Balcony', styleTag: 'Midnight', tags: ['starlight', 'party'] },
  { id: 'pastelBoutique', name: 'Ribbon Boutique', styleTag: 'Showroom', tags: ['pastel', 'idol', 'tea'] },
  { id: 'cloudMeadow', name: 'Cloud Meadow', styleTag: 'Daydream', tags: ['cozy', 'fairytale', 'soft'] },
  { id: 'checkeredCafe', name: 'Checkered Parlor', styleTag: 'Cafe', tags: ['academy', 'casual', 'pop'] },
];

export const DEFAULT_OUTFIT: ChibiOutfit = {
  skinTone: 'porcelain',
  eyeStyle: 'jewelRound',
  eyeColor: 'roseQuartz',
  mouthStyle: 'tinyDot',
  blushStyle: 'softOval',
  hairStyle: 'bobBuns',
  hairColor: 'silverLilac',
  dress: 'capeletBow',
  dressColor: 'cloudWhite',
  dressAccent: 'butterCream',
  top: 'none',
  topColor: 'cloudWhite',
  bottom: 'none',
  bottomColor: 'blushPink',
  socks: 'kneeRibbon',
  socksColor: 'cloudWhite',
  shoes: 'bowMaryJanes',
  shoesColor: 'blushPink',
  headwear: 'twinFlowerBows',
  headwearColor: 'blushPink',
  eyewear: 'none',
  neckwear: 'giantRibbon',
  neckwearColor: 'butterCream',
  backItem: 'none',
  backItemColor: 'cloudWhite',
  companion: 'creamLamb',
  backdrop: 'atelierCream',
};

export const STARTER_LOOKS: SavedLook[] = [
  {
    id: 'preset-cloud-berry',
    name: 'Cloud Blossom',
    createdAt: 'Curated Preset',
    isPreset: true,
    outfit: { ...DEFAULT_OUTFIT },
  },
  {
    id: 'preset-matcha-academy',
    name: 'Matcha Academy',
    createdAt: 'Curated Preset',
    isPreset: true,
    outfit: {
      skinTone: 'peach',
      eyeStyle: 'jewelRound',
      eyeColor: 'emeraldMint',
      mouthStyle: 'sweetSmile',
      blushStyle: 'freckles',
      hairStyle: 'sidePony',
      hairColor: 'cocoaBrown',
      dress: 'none',
      dressColor: 'cloudWhite',
      dressAccent: 'sageMint',
      top: 'knitCardigan',
      topColor: 'sageMint',
      bottom: 'pleatedSkirt',
      bottomColor: 'navyInk',
      socks: 'kneeRibbon',
      socksColor: 'cloudWhite',
      shoes: 'platformLoafers',
      shoesColor: 'velvetNoir',
      headwear: 'fluffyBeret',
      headwearColor: 'butterCream',
      eyewear: 'roundGlasses',
      neckwear: 'none',
      neckwearColor: 'butterCream',
      backItem: 'none',
      backItemColor: 'cloudWhite',
      companion: 'ribbonTote',
      backdrop: 'checkeredCafe',
    },
  },
  {
    id: 'preset-midnight-starlight',
    name: 'Midnight Starlight',
    createdAt: 'Curated Preset',
    isPreset: true,
    outfit: {
      skinTone: 'warmIvory',
      eyeStyle: 'starrySparkle',
      eyeColor: 'lavender',
      mouthStyle: 'kitty',
      blushStyle: 'heartCheek',
      hairStyle: 'curlyWaves',
      hairColor: 'midnightInk',
      dress: 'starlightGown',
      dressColor: 'lavenderMist',
      dressAccent: 'butterCream',
      top: 'none',
      topColor: 'cloudWhite',
      bottom: 'none',
      bottomColor: 'lavenderMist',
      socks: 'laceTights',
      socksColor: 'velvetNoir',
      shoes: 'ribbonBallet',
      shoesColor: 'lavenderMist',
      headwear: 'crownTiara',
      headwearColor: 'butterCream',
      eyewear: 'none',
      neckwear: 'pearlChoker',
      neckwearColor: 'velvetNoir',
      backItem: 'fairyWings',
      backItemColor: 'lavenderMist',
      companion: 'starLantern',
      backdrop: 'starryNight',
    },
  },
];

export const STYLE_CHALLENGES: StyleChallengePrompt[] = [
  {
    id: 'tea-party',
    title: 'Pastel Tea Party',
    brief: 'Style a delicate afternoon tea outfit with soft ribbons, dainty shoes, and sweet companion charm.',
    requiredTags: ['tea', 'pastel', 'sweet'],
    recommendedBackdrop: 'sakuraGarden',
    minScore: 70,
  },
  {
    id: 'starlight-gala',
    title: 'Midnight Starlight',
    brief: 'Dress for a rooftop starry gala using luminous accessories, wings or tiara, and evening elegance.',
    requiredTags: ['starlight', 'party', 'fairytale'],
    recommendedBackdrop: 'starryNight',
    minScore: 70,
  },
  {
    id: 'academy-prep',
    title: 'Boutique Academy',
    brief: 'Compose a smart preppy campus look with pleated skirts or blazers, loafers, and scholarly accents.',
    requiredTags: ['academy', 'chic', 'classic'],
    recommendedBackdrop: 'checkeredCafe',
    minScore: 70,
  },
  {
    id: 'cozy-sunday',
    title: 'Cozy Cloud Sunday',
    brief: 'Create an ultra-soft weekend outfit with warm knitwear or sleepwear, plush companions, and cozy socks.',
    requiredTags: ['cozy', 'soft'],
    recommendedBackdrop: 'cloudMeadow',
    minScore: 70,
  },
];

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateCohesiveRandomOutfit(): ChibiOutfit {
  const useDress = Math.random() > 0.42;
  const primary = pick(GARMENT_COLORS).id;
  const accent = pick(GARMENT_COLORS.filter((c) => c.id !== primary)).id;

  const dresses = DRESS_ITEMS.filter((d) => d.id !== 'none');
  const tops = TOP_ITEMS.filter((t) => t.id !== 'none');
  const bottoms = BOTTOM_ITEMS.filter((b) => b.id !== 'none');
  const shoes = SHOE_ITEMS.filter((s) => s.id !== 'none');

  return {
    skinTone: pick(Object.keys(SKIN_TONES) as SkinToneId[]),
    eyeStyle: pick(EYE_STYLES).id,
    eyeColor: pick(EYE_COLORS).id,
    mouthStyle: pick(MOUTH_STYLES).id,
    blushStyle: pick(BLUSH_STYLES).id,
    hairStyle: pick(HAIR_STYLES).id,
    hairColor: pick(HAIR_COLORS).id,
    dress: useDress ? pick(dresses).id : 'none',
    dressColor: primary,
    dressAccent: accent,
    top: useDress ? 'none' : pick(tops).id,
    topColor: primary,
    bottom: useDress ? 'none' : pick(bottoms).id,
    bottomColor: accent,
    socks: pick(SOCK_ITEMS).id,
    socksColor: Math.random() > 0.5 ? 'cloudWhite' : accent,
    shoes: pick(shoes).id,
    shoesColor: Math.random() > 0.4 ? accent : primary,
    headwear: Math.random() > 0.2 ? pick(HEADWEAR_ITEMS.filter((h) => h.id !== 'none')).id : 'none',
    headwearColor: accent,
    eyewear: Math.random() > 0.72 ? pick(EYEWEAR_ITEMS.filter((e) => e.id !== 'none')).id : 'none',
    neckwear: Math.random() > 0.35 ? pick(NECKWEAR_ITEMS.filter((n) => n.id !== 'none')).id : 'none',
    neckwearColor: accent,
    backItem: Math.random() > 0.68 ? pick(BACK_ITEMS.filter((b) => b.id !== 'none')).id : 'none',
    backItemColor: primary,
    companion: Math.random() > 0.25 ? pick(COMPANION_ITEMS.filter((c) => c.id !== 'none')).id : 'none',
    backdrop: pick(BACKDROP_ITEMS).id,
  };
}
