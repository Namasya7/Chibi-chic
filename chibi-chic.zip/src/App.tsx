import React, { useEffect, useRef, useState } from 'react';
import {
  BookmarkPlus,
  Download,
  Redo2,
  RotateCcw,
  Shuffle,
  Undo2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ChibiStageSvg } from './components/ChibiStageSvg';
import { LookbookView } from './components/LookbookView';
import { StudioGuideView } from './components/StudioGuideView';
import { StyleChallengeView } from './components/StyleChallengeView';
import { WardrobePanel } from './components/WardrobePanel';
import {
  DEFAULT_OUTFIT,
  STARTER_LOOKS,
  generateCohesiveRandomOutfit,
} from './data/wardrobeCatalog';
import { AppSection, CategoryId, ChibiOutfit, SavedLook } from './types/wardrobe';
import { exportSvgToPng } from './utils/exportPng';
import { playChordShimmer, playEquipChime } from './utils/sound';

const STORAGE_LOOKS_KEY = 'chibi-chic-saved-looks-v1';
const STORAGE_CHALLENGES_KEY = 'chibi-chic-completed-challenges-v1';

export default function App() {
  const [section, setSection] = useState<AppSection>('studio');
  const [activeCategory, setActiveCategory] = useState<CategoryId>('dresses');
  const [outfit, setOutfit] = useState<ChibiOutfit>(DEFAULT_OUTFIT);
  const [history, setHistory] = useState<ChibiOutfit[]>([DEFAULT_OUTFIT]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  const [lookName, setLookName] = useState<string>('Cloud Blossom');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [floatEnabled, setFloatEnabled] = useState<boolean>(true);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const stageSvgRef = useRef<SVGSVGElement | null>(null);

  const [userLooks, setUserLooks] = useState<SavedLook[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_LOOKS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as SavedLook[];
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  const [completedChallenges, setCompletedChallenges] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_CHALLENGES_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as string[];
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LOOKS_KEY, JSON.stringify(userLooks));
    } catch {
      // Ignore storage errors
    }
  }, [userLooks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CHALLENGES_KEY, JSON.stringify(completedChallenges));
    } catch {
      // Ignore storage errors
    }
  }, [completedChallenges]);

  useEffect(() => {
    if (!statusMessage) return;
    const timer = window.setTimeout(() => setStatusMessage(null), 2600);
    return () => window.clearTimeout(timer);
  }, [statusMessage]);

  const commitOutfit = (next: ChibiOutfit, chime: 'equip' | 'chord' = 'equip') => {
    setOutfit(next);
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIndex + 1);
      const updated = [...sliced, next].slice(-30);
      setHistoryIndex(updated.length - 1);
      return updated;
    });
    if (chime === 'chord') {
      playChordShimmer(soundEnabled);
    } else {
      playEquipChime(soundEnabled);
    }
  };

  const handleUpdateOutfit = (patch: Partial<ChibiOutfit>) => {
    commitOutfit({ ...outfit, ...patch }, 'equip');
  };

  const handleSelectDress = (dressId: ChibiOutfit['dress']) => {
    if (dressId === 'none') {
      commitOutfit(
        {
          ...outfit,
          dress: 'none',
          top: outfit.top === 'none' ? 'peterPanBlouse' : outfit.top,
          bottom: outfit.bottom === 'none' ? 'pleatedSkirt' : outfit.bottom,
        },
        'equip'
      );
    } else {
      commitOutfit(
        {
          ...outfit,
          dress: dressId,
          top: 'none',
          bottom: 'none',
        },
        'equip'
      );
    }
  };

  const handleSelectTop = (topId: ChibiOutfit['top']) => {
    commitOutfit(
      {
        ...outfit,
        dress: 'none',
        top: topId,
        bottom: outfit.bottom === 'none' && outfit.dress !== 'none' ? 'pleatedSkirt' : outfit.bottom,
      },
      'equip'
    );
  };

  const handleSelectBottom = (bottomId: ChibiOutfit['bottom']) => {
    commitOutfit(
      {
        ...outfit,
        dress: 'none',
        bottom: bottomId,
        top: outfit.top === 'none' && outfit.dress !== 'none' ? 'peterPanBlouse' : outfit.top,
      },
      'equip'
    );
  };

  const handleUndo = () => {
    if (historyIndex <= 0) return;
    const nextIdx = historyIndex - 1;
    setHistoryIndex(nextIdx);
    setOutfit(history[nextIdx]);
    playEquipChime(soundEnabled);
  };

  const handleRedo = () => {
    if (historyIndex >= history.length - 1) return;
    const nextIdx = historyIndex + 1;
    setHistoryIndex(nextIdx);
    setOutfit(history[nextIdx]);
    playEquipChime(soundEnabled);
  };

  const handleRandomize = () => {
    const next = generateCohesiveRandomOutfit();
    setLookName('Custom Mix');
    commitOutfit(next, 'chord');
    setStatusMessage('Styled a new surprise look');
  };

  const handleReset = () => {
    setLookName('Cloud Blossom');
    commitOutfit(DEFAULT_OUTFIT, 'equip');
    setStatusMessage('Reset to Cloud Blossom');
  };

  const handleSaveLook = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = lookName.trim() || `Look ${userLooks.length + 1}`;
    const today = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
    const newLook: SavedLook = {
      id: `look-${Date.now()}`,
      name: cleanName,
      createdAt: today,
      outfit: { ...outfit },
    };
    setUserLooks((prev) => [newLook, ...prev]);
    playChordShimmer(soundEnabled);
    setStatusMessage(`Saved "${cleanName}" to Lookbook`);
  };

  const handleLoadLook = (loadedOutfit: ChibiOutfit, name: string) => {
    setLookName(name);
    commitOutfit({ ...loadedOutfit }, 'chord');
    setSection('studio');
    setStatusMessage(`Wearing "${name}"`);
  };

  const handleDeleteLook = (id: string) => {
    setUserLooks((prev) => prev.filter((item) => item.id !== id));
  };

  const handleExportPng = async () => {
    if (isExporting) return;
    setIsExporting(true);
    const ok = await exportSvgToPng(stageSvgRef.current, lookName);
    setIsExporting(false);
    if (ok) {
      playChordShimmer(soundEnabled);
      setStatusMessage('Downloaded PNG portrait');
    } else {
      setStatusMessage('Open Studio view to export PNG');
    }
  };

  const allLookbookEntries = [...userLooks, ...STARTER_LOOKS];

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F6] text-[#2D2129]">
      {/* Top Bar — Strict 3-Zone Contract */}
      <header className="bg-white border-b border-[#EAE2DE]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-element Brand Wordmark */}
          <button
            type="button"
            onClick={() => setSection('studio')}
            className="font-display text-2xl font-semibold tracking-tight text-[#2D2129] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C84B78]"
          >
            Chibi Chic
          </button>

          {/* Zone 2: Concise single-line nav links */}
          <nav aria-label="Primary" className="hidden md:flex items-center gap-7 text-sm font-medium">
            {(
              [
                { id: 'studio', label: 'Studio' },
                { id: 'lookbook', label: 'Lookbook' },
                { id: 'challenge', label: 'Challenges' },
                { id: 'guide', label: 'Guide' },
              ] as { id: AppSection; label: string }[]
            ).map((item) => {
              const active = section === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSection(item.id)}
                  className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#C84B78] ${
                    active
                      ? 'border-[#C84B78] text-[#2D2129] font-semibold'
                      : 'border-transparent text-[#6E5C66] hover:text-[#2D2129]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary CTA */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => {
                if (section !== 'studio') {
                  setSection('studio');
                  window.setTimeout(() => {
                    void handleExportPng();
                  }, 60);
                } else {
                  void handleExportPng();
                }
              }}
              disabled={isExporting}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-[#C84B78] text-white hover:bg-[#B23D67] disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C84B78]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Exporting' : 'Save PNG'}</span>
            </button>
          </div>
        </div>

        {/* Mobile compact navigation strip */}
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-[#F0E9E5] px-4 py-2 flex items-center justify-around gap-2"
        >
          {(
            [
              { id: 'studio', label: 'Studio' },
              { id: 'lookbook', label: 'Lookbook' },
              { id: 'challenge', label: 'Challenges' },
              { id: 'guide', label: 'Guide' },
            ] as { id: AppSection; label: string }[]
          ).map((item) => {
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSection(item.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap shrink-0 ${
                  active ? 'bg-[#FDF1F5] text-[#C84B78]' : 'text-[#6E5C66]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-[1280px] w-full mx-auto px-4 sm:px-8 py-6 sm:py-8">
        {section === 'studio' && (
          <div className="space-y-6">
            {/* Compact Workspace Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#2D2129] text-balance">
                  Dress-Up Studio
                </h1>
                <p className="text-sm text-[#6E5C66] mt-0.5">
                  Mix hairstyles, dresses, separates, shoes, accessories, and companions.
                </p>
              </div>

              {statusMessage && (
                <div
                  role="status"
                  className="text-xs font-medium text-[#9F2E57] bg-[#FDF4F7] border border-[#F0D3DF] px-3.5 py-2 rounded-lg self-start sm:self-auto"
                >
                  {statusMessage}
                </div>
              )}
            </div>

            {/* 2-Column Studio Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Left Column: Live Chibi Stage */}
              <div className="lg:col-span-5 flex flex-col gap-4">
                <div className="bg-white border border-[#EAE2DE] rounded-2xl p-4 sm:p-5 flex flex-col flex-1">
                  {/* Stage Action Toolbar */}
                  <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#F0E9E5]">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleUndo}
                        disabled={historyIndex <= 0}
                        aria-label="Undo change"
                        title="Undo"
                        className="p-2 rounded-lg border border-[#EAE2DE] text-[#5B4A53] hover:bg-[#F8F3F0] disabled:opacity-35 disabled:pointer-events-none transition-colors"
                      >
                        <Undo2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={handleRedo}
                        disabled={historyIndex >= history.length - 1}
                        aria-label="Redo change"
                        title="Redo"
                        className="p-2 rounded-lg border border-[#EAE2DE] text-[#5B4A53] hover:bg-[#F8F3F0] disabled:opacity-35 disabled:pointer-events-none transition-colors"
                      >
                        <Redo2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setSoundEnabled((s) => !s)}
                        aria-label={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
                        title={soundEnabled ? 'Sound On' : 'Sound Muted'}
                        className="p-2 rounded-lg border border-[#EAE2DE] text-[#5B4A53] hover:bg-[#F8F3F0] transition-colors"
                      >
                        {soundEnabled ? (
                          <Volume2 className="w-4 h-4" />
                        ) : (
                          <VolumeX className="w-4 h-4" />
                        )}
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleRandomize}
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-[#2D2129] text-white hover:bg-[#463640] transition-colors whitespace-nowrap shrink-0"
                      >
                        <Shuffle className="w-3.5 h-3.5" />
                        <span>Surprise</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleReset}
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-[#EAE2DE] text-[#5B4A53] hover:bg-[#F8F3F0] transition-colors whitespace-nowrap shrink-0"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reset</span>
                      </button>
                    </div>
                  </div>

                  {/* Character Viewport */}
                  <div className="relative bg-[#FAF7F4] border border-[#EFE7E3] rounded-xl flex-1 min-h-[380px] sm:min-h-[430px] flex items-center justify-center overflow-hidden p-2">
                    <div className={floatEnabled ? 'chibi-float w-full flex justify-center' : 'w-full flex justify-center'}>
                      <ChibiStageSvg
                        svgRef={stageSvgRef}
                        outfit={outfit}
                        className="w-full max-w-[330px] h-auto select-none"
                      />
                    </div>
                  </div>

                  {/* Save to Lookbook Form & Pose Motion Toggle */}
                  <form onSubmit={handleSaveLook} className="mt-4 flex flex-wrap sm:flex-nowrap items-center gap-2">
                    <label htmlFor="look-name-input" className="sr-only">
                      Outfit name
                    </label>
                    <input
                      id="look-name-input"
                      type="text"
                      maxLength={32}
                      value={lookName}
                      onChange={(e) => setLookName(e.target.value)}
                      placeholder="Name this outfit..."
                      className="flex-1 min-w-[140px] px-3 py-2 text-sm bg-[#FAF8F6] border border-[#E5DCD7] rounded-lg text-[#2D2129] placeholder:text-[#9A8992] focus:outline-none focus:border-[#C84B78]"
                    />
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-[#C84B78] text-white hover:bg-[#B23D67] transition-colors whitespace-nowrap shrink-0"
                    >
                      <BookmarkPlus className="w-3.5 h-3.5" />
                      <span>Save Look</span>
                    </button>
                  </form>

                  {/* Quick Starter Presets */}
                  <div className="mt-4 pt-3 border-t border-[#F0E9E5] flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs text-[#87747E] mr-1">Presets:</span>
                      {STARTER_LOOKS.map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => handleLoadLook(preset.outfit, preset.name)}
                          className="px-2.5 py-1 text-xs font-medium rounded-md bg-[#F6F1EE] text-[#4E3E47] hover:bg-[#ECE2DF] transition-colors whitespace-nowrap shrink-0"
                        >
                          {preset.name}
                        </button>
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={() => setFloatEnabled((f) => !f)}
                      className="text-xs text-[#7D6A74] hover:text-[#2D2129] whitespace-nowrap shrink-0"
                    >
                      Idle Pose: {floatEnabled ? 'On' : 'Off'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Wardrobe Drawer */}
              <div className="lg:col-span-7">
                <WardrobePanel
                  activeCategory={activeCategory}
                  onSelectCategory={setActiveCategory}
                  outfit={outfit}
                  onUpdateOutfit={handleUpdateOutfit}
                  onSelectDress={handleSelectDress}
                  onSelectTop={handleSelectTop}
                  onSelectBottom={handleSelectBottom}
                />
              </div>
            </div>
          </div>
        )}

        {section === 'lookbook' && (
          <LookbookView
            looks={allLookbookEntries}
            onLoadLook={handleLoadLook}
            onDeleteLook={handleDeleteLook}
            onReturnToStudio={() => setSection('studio')}
          />
        )}

        {section === 'challenge' && (
          <StyleChallengeView
            outfit={outfit}
            completedIds={completedChallenges}
            onCompleteChallenge={(id) =>
              setCompletedChallenges((prev) => (prev.includes(id) ? prev : [...prev, id]))
            }
            onGoToStudio={() => setSection('studio')}
          />
        )}

        {section === 'guide' && (
          <StudioGuideView onReturnToStudio={() => setSection('studio')} />
        )}
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-[#EAE2DE] bg-white mt-auto">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#87747E]">
          <span>Chibi Chic · Pastel Boutique Dress-Up Studio</span>
          <span>{allLookbookEntries.length} looks in Lookbook</span>
        </div>
      </footer>
    </div>
  );
}
